#include <vector>
#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <ftw.h>
#include "MersenneTwister.h"

MTRand twister;

int isValidDomain(char *p)
{
	// require strlen(p)>2
	if(p[0]=='\0' || p[1]=='\0' || p[2]=='\0' || p[0]=='.') {
		return 0;
	}

	do {
		if(!isalnum(*p) && *p!='.' && *p!='-' && *p!='_') {
			return 0;
		}
		++p;
	} while(*p != '\0');

	return 1;
}

void lowerstr(char *s)
{
	while(*s != '\0') {
		*s = tolower(*s);
		++s;
	}
}

void shuffle(std::vector<char *> &v)
{
	size_t sz = v.size();

	for(size_t i = 0; i < sz; i++) {
		std::swap(v[twister.randInt(sz - 1)],
			  v[twister.randInt(sz - 1)]);

	}
}

void writeOutAndClear(std::vector<char *> &v, FILE *fp)
{
	for(std::vector<char *>::iterator it = v.begin(); it != v.end(); ++it) {
		size_t len = strlen(*it);
		
		fputc(static_cast<unsigned char>(len), fp);
		fwrite(*it, 1, len, fp);
		free(*it);
	}

	v.clear();
}

void split(const char *fname)
{
	char buf[511], lastdomain[256], lastdir[8], *p;
	size_t len;
	FILE *ifp, *ofp;
	std::vector<char *> emails;
	
	snprintf(buf, sizeof(buf), "sort -f -t '@' -k2 ../%s -T /usr/tmp", fname);
/*	for(int i = 2; i < argc; i++) {
		strcat(buf, " ");
		strcat(buf, fname);
	}*/

	ifp = popen(buf, "r");
	if(ifp == NULL) {
		perror(buf);
		exit(1);
	}

	lastdomain[0] = '\0';
	lastdir[0] = '\0';

	while(!feof(ifp)) {
		if(fgets(buf, sizeof(buf), ifp) == NULL) {
			break;
		}

		if(buf[0] == '\0') {
			continue;
		}

		p = buf + strlen(buf) - 1;
		while(isspace(*p)) {
			*p-- = '\0';
		}

		p = strchr(buf, '@');
		if(p == NULL) {
			printf("bad address: %s\n", buf);
			continue;
		}

		*p++ = '\0';
		len = strlen(buf);
		if(len == 0) {
			printf("bad address: %s\n", buf);
			continue;
		}

		if(len > 254) {
			printf("address too long: %s@%s\n", buf, p);
			continue;
		}

		if(!isValidDomain(p)) {
			printf("bad domain %s\n", p);
			continue;
		}

		lowerstr(p);

		if(lastdir[0] == '\0') {
			printf("%s\n", lastdir);
			if(lastdir[0] != '\0') {
				if(chdir("..") != 0) {
					perror("cannot chdir to '..'");
					exit(1);
				}
			}

			memcpy(lastdir, p, 2);
			lastdir[2] = '\0';
			mkdir(lastdir, 0777);
			if(chdir(lastdir) != 0) {
				perror(lastdir);
				exit(1);
			}
		}

		if(lastdomain[0] == '\0') {
			strncpy(lastdomain, p, sizeof(lastdomain));
		}

		if(strcmp(lastdomain, p) != 0) {
			ofp = fopen(lastdomain, "a");
			if(ofp == NULL) {
				perror(lastdomain);
				exit(1);
			}
			shuffle(emails);
			writeOutAndClear(emails, ofp);
			fclose(ofp);

			strncpy(lastdomain, p, sizeof(lastdomain));
		}

		if(memcmp(lastdir, p, 2) != 0) {
			printf("%s\n", lastdir);
			if(lastdir[0] != '\0') {
				if(chdir("..") != 0) {
					perror("cannot chdir to '..'");
					exit(1);
				}
			}

			memcpy(lastdir, p, 2);
			lastdir[2] = '\0';
			mkdir(lastdir, 0777);
			if(chdir(lastdir) != 0) {
				perror(lastdir);
				exit(1);
			}
		}
		
		emails.push_back(strdup(buf));
	}

	if(!emails.empty()) {
		ofp = fopen(lastdomain, "a");
		if(ofp == NULL) {
			perror(p);
			exit(1);
		}
		shuffle(emails);
		writeOutAndClear(emails, ofp);
		fclose(ofp);
	}

	pclose(ifp);
	
	if(lastdir[0] != '\0') {
		if(chdir("..") != 0) {
			perror("cannot chdir to '..'");
			exit(1);
		}
	}
}

FILE *g_outfp;

int filefn(const char *fpath, const struct stat *sb, int type)
{
	if(type==FTW_F && sb->st_size<128) {
		unsigned char len;
		char buf[256], *domain;
		FILE *fp;

		if(strstr(fpath, "REST") != NULL) {
			return 0;
		}

		domain = strrchr(fpath, '/');
		if(domain == NULL) {
			fprintf(stderr, "no / in pathname %s (?)\n", fpath);
			return 0;
		}
		++domain;

		fp = fopen(fpath, "r");
		if(fp == NULL) {
			perror(fpath);
			return 0;
		}

		while(!feof(fp)) {
			if(fread(&len, sizeof(len), 1, fp) != 1) {
				break;
			}
			if(fread(buf, len, 1, fp) != 1) {
				break;
			}
			buf[len] = '\0';
			fprintf(g_outfp, "%s@%s\n", buf, domain);
		}

		fclose(fp);

		unlink(fpath);
	} else if(type == FTW_D) {
		printf("%s\n", fpath);
	}
	
	return 0;
}

void cleanup()
{
	g_outfp = fopen("REST", "w");
	if(g_outfp == NULL) {
		perror("REST");
		exit(1);
	}

	ftw(".", filefn, 10);

	fclose(g_outfp);
}

int main(int argc, char *argv[])
{
	char buf[128];
	char *p;
	
	if(argc < 2) {
		printf("usage %s <list>\n", argv[0]);
		return 1;
	}

	p = strrchr(argv[1], '/');
	if(p != NULL) {
		*p++ = '\0';
		if(chdir(argv[1]) != 0) {
			perror(argv[1]);
			exit(1);
		}
	} else {
		p = argv[1];
	}

	snprintf(buf, sizeof(buf), "%s.d", p);
	if(mkdir(buf, 0777) != 0) {
		perror(buf);
		exit(1);
	}

	if(chdir(buf) != 0) {
		perror(buf);
		exit(1);
	}

	split(p);
//	cleanup();
//	system("rmdir -- ??");

	return 0;
}

