#include <vector>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <time.h>

#define BUFSIZE 32768

#define PROTODEBUG

struct thinfo
{
	sockaddr_in addr;
	int iters;
	int cfgver;
};

	enum
	{
		MSG_NONE,
		MSG_HELO,
		MSG_PING,
		MSG_READY,
		MSG_DONE,
		MSG_LOG
	};

	enum
	{
		RESP_NONE,
		RESP_HELO,
		RESP_PONG,
		RESP_EMAILS,
		RESP_CONFIG,
		RESP_UPDATE,
		RESP_IDLE,
		RESP_QUIT
	};

	enum
	{
		CLIENT_CAN_MAIL = 1
	};
	
	struct MsgHeader
	{
		unsigned int msg;
		unsigned int size;
	};

	struct HeloMsg
	{
		unsigned int version;
		unsigned int protover;
		char id[16];
		unsigned int flags;
	};

	struct HeloResp
	{
		unsigned int version;
		in_addr ip;
	};

	struct UpdateResp
	{
		char url[1];
	};

	struct IdleResp
	{
		unsigned int seconds;
	};

	struct QuitResp
	{
		unsigned int seconds;
	};

	union Buffer
	{
		char c[BUFSIZE];
		struct {
			MsgHeader header;
			union
			{
				char body[1];

				HeloMsg heloMsg;

				HeloResp heloResp;
				UpdateResp updateResp;
				IdleResp idleResp;
				QuitResp quitResp;
			};
		};
	};

pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
unsigned int nrecvd = 0;
time_t tstart;
unsigned int id = 0;

void checkDataBuf(char *buf, size_t len)
{
	size_t i = 0, n;

//	printf("--------\n");
	while(++i < len) {
		n = ((unsigned char*)buf)[i++];
		if(i+n > len) {
			printf("overflow\n");
			exit(1);
			break;
		}

		if(n == 0) {
			printf("zero\n");
			exit(1);
		}

//		printf("*");
		for(size_t j = 0; j < n; j++, i++) {
			if(!isprint(buf[i])) {
				printf("bad char\n");
				exit(1);
			} else {
//				printf("%c", buf[i]);
			}
		}
//		printf("*\n");
	}
}
/*
void doWorkData(int s, Buffer *bp)
{
	int n = -1; // skip domain
	int ns = 0, nf = 0, nu = 0;
	
	for(size_t i = sizeof(MsgHeader); i < bp->header.size; i++) {
		if(bp->c[i] == '\0') {
			++n;
			switch(rand() % 3) {
			case 0: ++ns; break;
			case 1: ++nf; break;
			case 2: ++nu; break;
			}
		}
	}

	if(n <= 0) {
		printf("zero email work bucker?!\n");
		return;
	} else
		printf("%d\n", n);
	
	bp->header.msg = MSG_WORKDONE;
	bp->header.size = sizeof(MsgHeader) + sizeof(WorkDoneMsg);
	bp->workDoneMsg.sent = ns;
	bp->workDoneMsg.failed = nf;
	bp->workDoneMsg.unlucky = nu;

	send(s, bp->c, bp->header.size, 0);
}

void doTestData(int s, Buffer *bp)
{
	int n = 0;
	
	bp->c[bp->header.size] = '\0';
	for(size_t i = sizeof(MsgHeader); i < bp->header.size; i++) {
		if(bp->c[i] == '\0') {
			++n;
			if(i>sizeof(MsgHeader) && bp->c[i-1]==0) {
				printf("WTF!\n");
			}
		}
	}

	if(n <= 0) {
		printf("zero email test bucket?!\n");
		return;
	}
	
	bp->header.msg = MSG_TESTDONE;
	bp->header.size = sizeof(MsgHeader) + n;

	for(int i = 0; i < n; i++) {
		bp->body[i] = rand() % 3;
	}

	send(s, bp->c, bp->header.size, 0);
}
*/

int recvn(int s, void *buf, unsigned int n, int flags)
{
	char *p = reinterpret_cast<char *>(buf);
	unsigned int m = 0;

	while(m < n) {
		int i = recv(s, p+m, n-m, flags);
		if(i <= 0) {
			return i;
		}
		m += i;
	}

	return m;
}

void readResp(int s, Buffer *bp)
{
	recvn(s, &bp->header, sizeof(MsgHeader), 0);
	if(bp->header.size > sizeof(MsgHeader)) {
		recvn(s, bp->body, bp->header.size - sizeof(MsgHeader), 0);
	}

	switch(bp->header.msg) {
#ifdef PROTODEBUG
	case RESP_HELO:
		printf("> HELO[%d]: ip:%s\n",
			bp->header.size,
			inet_ntoa(bp->heloResp.ip));
		break;
	case RESP_PONG:
		printf("> PONG[%d]\n",
			bp->header.size);
		break;
#endif
	case RESP_EMAILS:
#ifdef PROTODEBUG
		printf("> EMAILS[%d]\n",
			bp->header.size);
#endif
		bp->header.msg = MSG_DONE;
		for(char *p = bp->body; p < &bp->c[bp->header.size]; p++) {
			if(*p == 0) *p = rand() % 4;
		}
		checkDataBuf(bp->body, bp->header.size-sizeof(MsgHeader));
		send(s, bp, bp->header.size, 0);
//		doTestData(s, bp);
		break;
#ifdef PROTODEBUG
	case RESP_UPDATE:
		printf("> UPDATE[%d]: '%s'\n",
			bp->header.size,
			bp->updateResp.url);
		break;
	case RESP_IDLE:
		printf("> IDLE[%d]: %d\n",
			bp->header.size,
			bp->idleResp.seconds);
		break;
	case RESP_CONFIG:
		printf("> CONFIG[%d]\n",
			bp->header.size);
		break;
	default:
		printf("> UNKNOWN[%d]: %d\n",
			bp->header.size,
			bp->header.msg);
#endif
	}
}

void *thmain(void *arg)
{
	const thinfo * infop = reinterpret_cast<thinfo *>(arg);
	sockaddr_in addr = infop->addr;
	Buffer buf;
	int csock, i;

	srand(time(NULL));

	csock = socket(PF_INET, SOCK_STREAM, 0);
	if(connect(csock, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) == -1) {
		perror("connect");
	}

	readResp(csock, &buf);

	buf.header.msg = MSG_HELO;
	buf.header.size = sizeof(MsgHeader) + sizeof(HeloMsg);
	buf.heloMsg.version = infop->cfgver;
	buf.heloMsg.protover = 0x203;

	pthread_mutex_lock(&mtx);
	snprintf(buf.heloMsg.id, 17, "%016X", id++);
	pthread_mutex_unlock(&mtx);
	buf.heloMsg.flags = 1;

	for(unsigned int i = 0; i < buf.header.size; i+=1) {
		send(csock, &buf.c[i], 1, 0);
		usleep(20000);
	}

	readResp(csock, &buf);

	// ---
//	buf.header.msg = MSG_LOG;
//	buf.header.size = sizeof(MsgHeader) + 8;
//	send(csock, buf.c, sizeof(MsgHeader), 0);
//	send(csock, "LOGTEST\n", 8, 0);

	// --- 
	// should read config
	buf.header.msg = MSG_READY;
	buf.header.size = sizeof(MsgHeader);
	send(csock, buf.c, buf.header.size, 0);

	readResp(csock, &buf);

	// ---
//	buf.header.msg = MSG_PING;
//	buf.header.size = sizeof(MsgHeader);
//	send(csock, buf.c, buf.header.size, 0);

//	readResp(csock, &buf);

	// ---
	for(i = 0; i < infop->iters; i++) {
		buf.header.msg = MSG_READY;
		buf.header.size = sizeof(MsgHeader);
		send(csock, buf.c, buf.header.size, 0);

		readResp(csock, &buf);

		//usleep(2500000 + (rand()%25)*500000);
		usleep(25000 + (rand()%25)*5000);
	}
	
	close(csock);

	return NULL;
}

int main(int argc, char *argv[])
{
	thinfo info;
	std::vector<pthread_t> threads;
	size_t nthreads;

	if(argc != 6) {
		printf("usage: %s host port threads iters configver\n", argv[0]);
		return 1;
	}

	tstart = time(NULL);

	info.addr.sin_family = AF_INET;
	info.addr.sin_addr.s_addr = inet_addr(argv[1]);
	info.addr.sin_port = htons(atoi(argv[2]));
	info.iters = atoi(argv[4]);
	info.cfgver = atoi(argv[5]);
	nthreads = atoi(argv[3]);
	for(size_t i = 0; i < nthreads; i++) {
		pthread_t th;
		pthread_create(&th, NULL, thmain, &info);
		threads.push_back(th);
		usleep(60000);
	}

	for(size_t i = 0; i < nthreads; i++) {
		pthread_join(threads[i], NULL);
	}

printf("%.2f\n", (float)nrecvd/(time(NULL)-tstart));

	return 0;
}
