#ifndef _LISTENERTHREAD_H
#define _LISTENERTHREAD_H

#include <Thread.h>

class ListenerThread : public Thread
{
public:
	explicit ListenerThread(int port);
	virtual ~ListenerThread() {}

	void terminate()
	{
		run = false;
	}
private:
	bool run;

	int port;

	virtual void main();
};

#endif
