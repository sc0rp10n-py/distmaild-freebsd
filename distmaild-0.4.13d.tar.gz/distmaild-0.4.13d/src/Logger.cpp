#include <time.h>

#include <Logger.h>

Logger::Logger() 
	: logFile(NULL)
	, consLevel(LOG_WARNING)
	, fileLevel(LOG_INFO) 
{
	pthread_mutex_init(&mtx, NULL);
}

Logger::~Logger()
{
	pthread_mutex_destroy(&mtx);
}

bool Logger::setLogFile(const char *file, const char *mode)
{
	if(logFile != NULL) {
		fclose(logFile);
	}

	logFile = fopen(file, mode);

	return logFile != NULL;
}

void Logger::logf(int level, const char *fmt, ...)
{
	const char *prefix;
	char tstr[20];
	time_t t;
	tm lt;
	va_list args;

	switch(level) {
	case LOG_FATAL:   prefix = "fatal:  "; break;
	case LOG_ERROR:   prefix = "error:  "; break;
	case LOG_WARNING: prefix = "warning:"; break;
	case LOG_INFO:    prefix = "info:   "; break;
	case LOG_TRACE:   prefix = "trace:  "; break;
	default:          prefix = "UNKNOWN:"; break;
	}

	time(&t);
	localtime_r(&t, &lt);
	strftime(tstr, sizeof(tstr), "%b %d %H:%M:%S", &lt);

	va_start(args, fmt);
	pthread_mutex_lock(&mtx);
	if(level <= consLevel) {
		fprintf(stderr, "%s %s ", tstr, prefix);
		vfprintf(stderr, fmt, args);
	}
	if(level <= fileLevel && logFile!=NULL) {
		fprintf(logFile, "%s %s ", tstr, prefix);
		vfprintf(logFile, fmt, args);
		fflush(logFile);
	}
	pthread_mutex_unlock(&mtx);
	va_end(args);
}
