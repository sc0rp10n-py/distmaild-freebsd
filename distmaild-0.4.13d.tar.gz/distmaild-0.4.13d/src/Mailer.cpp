#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include <Mailer.h>
#include <EmailQueue.h>
#include <ListScanner.h>
#include <ServerConfig.h>
#include <Logger.h>

Mailer *Mailer::_this;

Mailer::Mailer()
: statThread("stats", 10)
, listenerThread(g_config->port)
, nextMarker(1)
, unluckyCollector(NULL)
, wantConfReload(false)
{
	pthread_rwlock_init(&queuesMutex, NULL);
	pthread_mutex_init(&refillMutex, NULL);
	pthread_cond_init(&refillCond, NULL);
	pthread_mutex_lock(&refillMutex);

	if(g_config->saveSent) {
		sentCollector = new EmailCollector("sent", 512*1024, g_config->appendSent);
		sentCollector->start();
	}

	if(g_config->saveFailed) {
		failedCollector = new EmailCollector("failed", 512*1024, g_config->appendFailed);
		failedCollector->start();
	}

	fromDomainsFile = fopen("fromdomains", "r");
	if(fromDomainsFile == NULL) {
		perror("fromdomains");
		exit(1);
	}
	
	emptyQueues       = new EmptyQueueVector;
	emptyQueuesTmp    = new EmptyQueueVector;
	finishedQueues    = new FinishedQueueVector;
	finishedQueuesTmp = new FinishedQueueVector;

	jobConfig.read();

	testIt = queues.end();
}

void Mailer::newClient(int sock, const sockaddr_in &addr)
{
	static int enable = 1;
	
	ioctl(sock, FIONBIO, &enable);
	if(clientThread.getNumClients() < g_config->maxClients) {
		clientThread.addClient(sock, addr);
	} else {
		close(sock);
	}
}

void Mailer::start()
{
	size_t totalDomains;

	statThread.start();
	listenerThread.start();
	clientThread.start();

	totalDomains = mailLoop("list");

	while(totalDomains > 0) {
		// XXX
		system("rm -rf unlucky.d");
		system("listprep unlucky");
		
		totalDomains = mailLoop("unlucky.d");
	}

	g_log.logf(LOG_INFO, "Finished!\n");
	exit(0);
}

bool Mailer::registerClient(const char *id)
{
	return clientsDb.insert(id).second;
}

void Mailer::unregisterClient(const char *id)
{
	clientsDb.erase(id);
}

// NOTE: do not reduce to clientsDb.size()
// cause this will not count pre-helo clients.
int Mailer::getTotalClients()
{

	return clientThread.getNumClients();
}

void Mailer::countClients(int &npreh, int &nidle, int &nwork, int &nquit)
{
	npreh = 0;
	nidle = 0;
	nwork = 0;
	nquit = 0;

	// HACK: this actually protects ClinetList inside ClientThread from StatThread...
	pthread_rwlock_rdlock(&queuesMutex);
	clientThread.countClients(npreh, nidle, nwork, nquit);
	pthread_rwlock_unlock(&queuesMutex);
}

void Mailer::getTestQueues(
	std::list<EmailQueue> &blackList,
	std::list<EmailQueue> &whiteList,
	std::list<EmailQueue> &testList,
	std::list<EmailQueue> &outList,
	int n)
{
	bool triedFirst = false;

	if(queues.empty()) {
		return;
	}

	for(std::list<EmailQueue>::iterator it = blackList.begin(); it != blackList.end(); ++it) {
		it->setMarker(nextMarker);
	}

	for(std::list<EmailQueue>::iterator it = whiteList.begin(); it != whiteList.end(); ++it) {
		it->setMarker(nextMarker);
	}

	for(std::list<EmailQueue>::iterator it = testList.begin(); it != testList.end(); ++it) {
		it->setMarker(nextMarker);
	}

	QueueList::iterator endIt = testIt;

	if(endIt == queues.end()) {
		endIt = queues.begin();
	}

	while(n>0 && (testIt!=endIt || !triedFirst)) {
		if(++testIt == queues.end()) {
			testIt = queues.begin();
		}

		if(testIt->getMarker()!=nextMarker && testIt->getState()==EmailQueue::STATE_NORMAL) {
			outList.push_back(*testIt);
			--n;
		}

		triedFirst = true;
	}

	if(++nextMarker == 0) {
		nextMarker = 1;
	}
}

void Mailer::queueEmpty(const EmailQueue &q)
{
	emptyQueues->push_back(q);
	pthread_cond_signal(&refillCond);
}

void Mailer::queueFinished(const EmailQueueToken &tk)
{
	finishedQueues->push_back(tk);
	pthread_cond_signal(&refillCond);
}

size_t Mailer::getFromDomains(char *buf, size_t maxsz, int n)
{
	char tmp[256];
	bool sought = false;
	size_t sz, totsz = 0;

	while(n--) {
again:
		if(fgets(tmp, sizeof(tmp), fromDomainsFile) == NULL) {
			if(!sought) {
				fseek(fromDomainsFile, 0, SEEK_SET);
				sought = true;
				goto again;
			} else {
				break;
			}
		}

		sz = strlen(tmp);
		if(tmp[sz - 1] == '\n') {
			tmp[sz - 1] = '\0';
		} else {
			sz++;
		}

		if(totsz+sz > maxsz) {
			break;
		}

		memcpy(buf+totsz, tmp, sz);
		totsz += sz;
	}

	return totsz;
}

size_t Mailer::getPoolSize()
{
	pthread_rwlock_wrlock(&queuesMutex);
	size_t ret = queues.size();
	pthread_rwlock_unlock(&queuesMutex);

	return ret;
}

size_t Mailer::mailLoop(char *listdir)
{
	QueueList tmpql;
	ListScanner ls(listdir);
	bool done = false;
	size_t ndomains = 0;
	const char *s;

	while((s=ls.nextQueue()) != NULL && ++ndomains<g_config->numQueues) {
		tmpql.push_front(EmailQueue());
		tmpql.front().assign(s, tmpql.begin());
		tmpql.front().fill();
	}

	pthread_rwlock_wrlock(&queuesMutex);

	emptyQueues->clear();
	emptyQueuesTmp->clear();
	finishedQueues->clear();
	finishedQueuesTmp->clear();

	if(unluckyCollector != NULL) {
		unluckyCollector->terminate();
		unluckyCollector->join();
		delete unluckyCollector;
	}

	unluckyCollector = new EmailCollector("unlucky", 512*1024, false);
	unluckyCollector->start();

	queues.splice(queues.begin(), tmpql);
	testIt = queues.begin();

	pthread_rwlock_unlock(&queuesMutex);

	while(!done) {
		if(wantConfReload) {
			jobConfig.read();
			wantConfReload = false;
		}

		pthread_rwlock_wrlock(&queuesMutex);
		
		std::swap(emptyQueues, emptyQueuesTmp);
		std::swap(finishedQueues, finishedQueuesTmp);

		FinishedQueueVector::iterator it;

		for(it = finishedQueuesTmp->begin();
			it!=finishedQueuesTmp->end() && (s=ls.nextQueue())!=NULL;
			++it)
		{
			(*it)->assign(s, *it);
			emptyQueuesTmp->push_back(**it);
		}

		for(; it != finishedQueuesTmp->end(); ++it) {
			if(testIt == *it) {
				++testIt;
			}
			queues.erase(*it);
		}

		if(queues.empty()) {
			done = true;
		}

		pthread_rwlock_unlock(&queuesMutex);

		for(EmptyQueueVector::iterator it = emptyQueuesTmp->begin();
			it != emptyQueuesTmp->end();
		       	++it) 
		{
			it->fill();
		}

		emptyQueuesTmp->clear();
		finishedQueuesTmp->clear();

		if(!done) {
			pthread_cond_wait(&refillCond, &refillMutex);
		}
		
	}

	return ndomains;
}
