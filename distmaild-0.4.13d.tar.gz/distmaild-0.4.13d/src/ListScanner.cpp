#include <string.h>

#include <ListScanner.h>
#include <Logger.h>

ListScanner::ListScanner(char *path)
{
	char * const paths[] = { path, NULL };
	
	fts = fts_open(paths, FTS_COMFOLLOW | FTS_LOGICAL
		| FTS_NOCHDIR | FTS_NOSTAT, NULL);
	if(fts == NULL) {
		g_log.logf(LOG_ERROR, "Cannot open list directory\n");
	}
}

ListScanner::~ListScanner()
{
	if(fts != NULL) {
		fts_close(fts);
	}	
}

const char *ListScanner::nextQueue()
{
	FTSENT *fe;
	
	if(fts == NULL) {
		return NULL;
	}

	do {
		fe = fts_read(fts);
	} while(fe!=NULL && (fe->fts_info!=FTS_F || strcmp(fe->fts_name, "REST")==0));

	return fe==NULL ? NULL : fe->fts_accpath;
}
