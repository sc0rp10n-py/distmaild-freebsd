#ifndef _CLIENTTHREAD_H
#define _CLIENTTHREAD_H

#include <list>
#include <utility>
#include <vector>
#include <netinet/in.h>
#include <pthread.h>

#include <Poller.h>
#include <Poller_kqueue.h>
#include <Thread.h>
#include <util.h>

class Client; // avoid circular dependancy

class ClientThread : public Thread
{
private:
	typedef std::list<Client *> ClientList;
public:
	typedef ClientList::iterator ClientToken;

	ClientThread();
	virtual ~ClientThread();

	void addClient(int sock, const sockaddr_in &addr);
	void removeClient(ClientToken &token)
	{
		deadClients.push_back(token);
	}

	int getNumClients()
	{
		return numClients;
	}

	Poller &getPoller()
	{
		return poller;
	}

	void countClients(int &npreh, int &nidle, int &nwork, int &nquit);
private:
	typedef std::vector<std::pair<int, sockaddr_in> > NewClientQueue;
	typedef std::vector<ClientToken> DeadClientQueue;
	
	int numClients;
	ClientList clientList;
	DeadClientQueue deadClients;
	NewClientQueue newClients;
	pthread_mutex_t newClientsMutex;

	Poller_kqueue poller;

	virtual void main();
};

#endif
