#include <string>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

#include <ServerConfig.h>
#include <JobConfig.h>
#include <Logger.h>

void JobConfig::read()
{
	std::string newcfg;
	Config cstruct;
	DIR *dp;
	dirent *de; 

	newcfg.resize(sizeof(Config));

	cstruct.minRecipients = readUInt("minrcpt");
	cstruct.maxRecipients = readUInt("maxrcpt");
	cstruct.numThreads = readUInt("nthreads");
	cstruct.delay = readUInt("delay");
	cstruct.maxMxs = readUInt("maxmxs");
	cstruct.logLevel = readUInt("loglevel");
	cstruct.flags = readBool("ignorehostname") ? CONFIG_IGNORE_CLIENT_HOSTNAME : 0;
	cstruct.failedStrsSize = readStrArr("failedstrs", newcfg);

	if(g_config->useProxyLock) {
		cstruct.numThreads = 0;
	}

	if(g_config->saveClientLogs) {
		cstruct.logLevel = 0;
	}
	
	dp = opendir("templates");
	if(dp == NULL) {
		g_log.logf(LOG_FATAL, "Cannot open dir templates\n");
		exit(1);
	}

	while((de = readdir(dp)) != NULL) {
		if(de->d_name[0] != '.') {
			util::refcnt<JobData> jdata;
			std::string cfg2(newcfg);
			char buf[256];
				
			snprintf(buf, sizeof(buf), "templates/%s", de->d_name);
			cstruct.templatesSize = readStr(buf, cfg2) + 1;
			cfg2 += '\0';

			cfg2.replace(0, sizeof(Config),
				reinterpret_cast<char *>(&cstruct), sizeof(Config));

			jdata.alloc();
			jdata->size = cfg2.size();
			jdata->ptr = new char[jdata->size];
			memcpy(jdata->ptr, cfg2.data(), jdata->size);
			configs.push_back(jdata);
		}
	}

	timestamp = time(NULL);
}

bool JobConfig::getData(util::refcnt<JobData> &cfg, time_t &ts)
{
	assert(timestamp != 0);
	assert(!configs.empty());
	
	if(ts != timestamp) {
		cfg = configs[rand() % configs.size()];
		ts = timestamp;
		return true;
	}

	return false;
}

bool JobConfig::readBool(const char *file)
{
	FILE *fp = fopen(file, "rb");

	if(fp == NULL) {
		return false;
	}

	fclose(fp);

	return true;
}

unsigned int JobConfig::readUInt(const char *file)
{
	FILE *fp = fopen(file, "rb");
	char buf[64];

	if(fp == NULL) {
		g_log.logf(LOG_FATAL, "Cannot open config file %s\n", file);
		exit(1);
	}

	fgets(buf, sizeof(buf), fp);
	fclose(fp);

	return strtoul(buf, NULL, 10);
}

unsigned int JobConfig::readStr(const char *file, std::string &s)
{
	FILE *fp = fopen(file, "rb");
	unsigned int n = 0;
	int c;

	if(fp == NULL) {
		g_log.logf(LOG_FATAL, "Cannot open config file %s\n", file);
		exit(1);
	}

	while((c = getc(fp)) != EOF) {
		s += c;
		++n;
	}

	fclose(fp);

	return n;
}

unsigned int JobConfig::readStrArr(const char *file, std::string &s)
{
	FILE *fp = fopen(file, "rb");
	unsigned int n = 0;
	int c;

	if(fp == NULL) {
		g_log.logf(LOG_FATAL, "Cannot open config file %s\n", file);
		exit(1);
	}

	while((c = getc(fp)) != EOF) {
		if(c == '\n') {
			s += '\0';
			++n;
		} else if(c != '\r') {
			s += c;
			++n;
		}
	}

	fclose(fp);

	return n;
}
