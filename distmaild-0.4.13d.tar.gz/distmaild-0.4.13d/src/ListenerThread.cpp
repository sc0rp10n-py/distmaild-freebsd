#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>

#include <Mailer.h>
#include <ListenerThread.h>
#include <Logger.h>

ListenerThread::ListenerThread(int p)
: run(true)
, port(p)
{}

void ListenerThread::main()
{
	static int enable = 1;
	int ssock, csock;
	sockaddr_in addr;
	socklen_t addrlen;

	ssock = socket(PF_INET, SOCK_STREAM, 0);
	if(ssock < 0) {
		perror("listener: socket()");
		return;
	}

	setsockopt(ssock, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(enable));
	
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	addr.sin_port = htons(port);
	if(bind(ssock, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) < 0) {
		g_log.logf(LOG_FATAL, "Listener: bind(): %s\n", strerror(errno));
		exit(1);
	}

	if(listen(ssock, 1024) < 0) {
		g_log.logf(LOG_FATAL, "Listener: listen(): %s\n", strerror(errno));
		exit(1);
	}

	while(run) {
		addrlen = sizeof(addr);
		csock = accept(ssock, reinterpret_cast<sockaddr *>(&addr), &addrlen);
		if(csock >= 0) {
			g_mailer.newClient(csock, addr);
		} else {
			g_log.logf(LOG_WARNING, "Listener: accept(): %s\n", strerror(errno));
		}
	}
}
