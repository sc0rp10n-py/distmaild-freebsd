#ifndef _VERSION_H
#define _VERSION_H

extern int g_verMajor;
extern int g_verMinor;
extern int g_verRelease;

#endif
