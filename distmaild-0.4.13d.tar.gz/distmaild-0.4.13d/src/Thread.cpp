#include <Thread.h>

void *Thread::_main(void *arg)
{
	Thread *_this = reinterpret_cast<Thread *>(arg);

	_this->main();

	return _this;
}
