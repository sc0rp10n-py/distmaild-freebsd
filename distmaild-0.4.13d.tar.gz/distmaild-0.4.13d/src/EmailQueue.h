#ifndef _EMAILQUEUE_H
#define _EMAILQUEUE_H

#include <functional>
#include <string>

#include <Mailer.h>

class EmailQueue
{
public:
	enum
	{
		STATE_NORMAL,
		STATE_EMPTY,
		STATE_FINISHED
	};

	EmailQueue();
	EmailQueue(const EmailQueue &x);
	~EmailQueue();

	void assign(const char *path, const Mailer::EmailQueueToken &tk);
	bool done();

	int getEmails(char *p, int n, size_t &sz);

	void setMarker(int marker);
	int  getMarker();
	bool fill();

	EmailQueue &operator =(const EmailQueue &x);

	// useful for stl
	inline static bool queueDone(EmailQueue &q)
	{
		return q.done();
	}

	inline int getState() const {
		assert(myData != NULL);

		return myData->state;
	}

	struct queueDoneProtected : public std::unary_function<EmailQueue &, bool>
	{
		queueDoneProtected(EmailQueue &pq) : protq(pq) {}
		bool operator ()(EmailQueue &q) { return &q!=&protq && q.done(); }
		EmailQueue &protq;
	};

	inline bool isDomainEqualTo(const char *p, size_t n)
	{
		assert(myData != NULL);

		bool eq = myData->domlen==n && memcmp(myData->domain, p, n)==0;

		return eq;
	}

	inline std::string _getDomain()
	{
		if(myData == NULL) {
			return "<DONE>";
		}

		std::string dom(myData->domain);

		return dom;
	}

	struct hash
	{
		inline size_t operator()(const EmailQueue &q)
		{
			return reinterpret_cast<size_t>(q.myData);
		}
	};
private:
	struct EmailData
	{
		unsigned char size;
		char name[1];
	};

	union EmailPtr
	{
		EmailData *ep;
		char *cp;
	};

	struct MyData
	{
		Mailer::EmailQueueToken token;

		char *fname;
		char *domain; // points to a substr of fname
		size_t domlen;

		EmailPtr blob;
		EmailPtr ptr;
		EmailPtr end;

		size_t curSize;
		int filePos;
		int state;
		int marker;
		int nRefs;
	};

	MyData *myData;
	
	void release();
};

#endif
