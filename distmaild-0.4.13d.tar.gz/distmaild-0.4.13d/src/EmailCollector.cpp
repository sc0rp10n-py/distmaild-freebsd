#include <algorithm>
#include <sys/time.h>
#include <stdio.h>
#include <errno.h>

#include <EmailCollector.h>
#include <Logger.h>

EmailCollector::EmailCollector(const char *file, size_t bufsz, bool a)
: done(false)
, memBufPos(0)
, diskBufPos(0)
, bufSize(bufsz)
, append(a)
, fileName(file)
{
	memBuf = new char[bufSize];
	diskBuf = new char[bufSize];

	pthread_mutex_init(&mutex, NULL);
	pthread_cond_init(&flushCond, NULL);
	pthread_mutex_init(&flushCondMutex, NULL);
}

EmailCollector::~EmailCollector()
{
	pthread_mutex_destroy(&flushCondMutex);
	pthread_cond_destroy(&flushCond);
	pthread_mutex_destroy(&mutex);

	delete [] diskBuf;
	delete [] memBuf;
}

bool EmailCollector::putEmail(const char *ep, size_t len, const char *dp, size_t dlen)
{
	bool ret = false;

	pthread_mutex_lock(&mutex);

	// Extra 2 bytes is for '@' and '\n' chars.
	if((len+dlen+2) <= (bufSize-memBufPos)) {
		memcpy(&memBuf[memBufPos], ep, len);
		memBufPos += len;
		memBuf[memBufPos++] = '@';
		memcpy(&memBuf[memBufPos], dp, dlen);
		memBufPos += dlen;
		memBuf[memBufPos++] = '\n';

		if(memBufPos*2 > bufSize) {
			pthread_cond_signal(&flushCond);
		}

		ret = true;
	}

	pthread_mutex_unlock(&mutex);

	return ret;
}

void EmailCollector::main()
{
	FILE *fp;
	timespec to;

	fp = fopen(fileName.c_str(), append ? "a" : "w");
	if(fp == NULL) {
		g_log.logf(LOG_FATAL, "Cannot open %s: %s\n", fileName.c_str(), strerror(errno));
		exit(2);
	}

	// Dummy mutex to server flushCond.
	// It is never released except just before exiting the thread
	// to make it destroyable.
	pthread_mutex_lock(&flushCondMutex);

	while(!done) {
		pthread_mutex_lock(&mutex);

		if(memBufPos > 0) {
			std::swap(memBuf, diskBuf);
			std::swap(memBufPos, diskBufPos);
		}

		pthread_mutex_unlock(&mutex);

		if(diskBufPos > 0) {
			if(fwrite(diskBuf, diskBufPos, 1, fp) != 1) {
				g_log.logf(LOG_ERROR, "Cannot write to file %s: %s\n",
					fileName.c_str(), strerror(errno));
			}

			if(fflush(fp) != 0) {
				g_log.logf(LOG_ERROR, "Cannot flush file %s: %s\n",
					fileName.c_str(), strerror(errno));
			}
			
			diskBufPos = 0;
		}

		clock_gettime(CLOCK_REALTIME, &to);

		to.tv_sec += 5;

		pthread_cond_timedwait(&flushCond, &flushCondMutex, &to);
	}

	pthread_mutex_unlock(&flushCondMutex);

	fclose(fp);
}
