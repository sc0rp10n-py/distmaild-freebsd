#ifndef _MAILER_H
#define _MAILER_H

#include <list>
#include <vector>
#include <ext/hash_set>
#include <netinet/in.h>
#include <assert.h>
#include <stdio.h>
#include <pthread.h>

#include <ClientThread.h>
#include <EmailCollector.h>
#include <JobConfig.h>
#include <StatThread.h>
#include <ListenerThread.h>
#include <util.h>

class EmailQueue;

class Mailer
{
private:
	typedef std::list<EmailQueue> QueueList;
public:
	typedef QueueList::iterator EmailQueueToken;

	void newClient(int sock, const sockaddr_in &addr);
	void start();

	bool registerClient(const char *id);
	void unregisterClient(const char *id);
	int  getTotalClients();
	void countClients(int &npreh, int &nidle, int &nwork, int &nquit);

	void reloadConfig() { wantConfReload = true; }

	void getTestQueues(
		std::list<EmailQueue> &blackList,
		std::list<EmailQueue> &whiteList,
		std::list<EmailQueue> &testList,
		std::list<EmailQueue> &outList,
		int n);

	void queueEmpty(const EmailQueue &q);
	void queueFinished(const EmailQueueToken &tk);

	void getBigLock()
	{
		pthread_rwlock_rdlock(&queuesMutex);
	}

	void releaseBigLock()
	{
		pthread_rwlock_unlock(&queuesMutex);
	}

	size_t getFromDomains(char *buf, size_t maxsz, int n);

	size_t getPoolSize();

	bool putSentEmail(const char *ep, size_t len, const char *dp, size_t dlen)
	{
		return sentCollector==NULL ? false : sentCollector->putEmail(ep, len, dp, dlen);
	}
	
	bool putFailedEmail(const char *ep, size_t len, const char *dp, size_t dlen)
	{
		return failedCollector==NULL ? false : failedCollector->putEmail(ep, len, dp, dlen);
	}

	bool putUnluckyEmail(const char *ep, size_t len, const char *dp, size_t dlen)
	{
		return unluckyCollector==NULL ? false : unluckyCollector->putEmail(ep, len, dp, dlen);
	}

	JobConfig &getJobConfig() { return jobConfig; }
	StatThread &getStatThread() { return statThread; }

	static void create()
	{
		assert(_this == NULL);
		_this = new Mailer;
	}
	
	static Mailer &getInstance()
	{
		assert(_this != NULL);
		return *_this;
	}
private:
	typedef std::vector<EmailQueue> EmptyQueueVector;
	typedef std::vector<EmailQueueToken> FinishedQueueVector;
	typedef __gnu_cxx::hash_set<const char *, __gnu_cxx::hash<const char *>, util::cstr_eq> ClientsDb;

	ClientThread clientThread;
	JobConfig jobConfig;
	StatThread statThread;
	ListenerThread listenerThread;

	QueueList queues;
	QueueList::iterator testIt;
	pthread_rwlock_t queuesMutex;
	int nextMarker;

	EmptyQueueVector *emptyQueues;
	EmptyQueueVector *emptyQueuesTmp;
	FinishedQueueVector *finishedQueues;
	FinishedQueueVector *finishedQueuesTmp;

	ClientsDb clientsDb;

	EmailCollector *sentCollector;
	EmailCollector *failedCollector;
	EmailCollector *unluckyCollector;

	bool wantConfReload;

	FILE *fromDomainsFile;

	pthread_mutex_t refillMutex;
	pthread_cond_t  refillCond;

	Mailer();

	/*
	 * These two members are purposedly left unimplemented.
	 */
	Mailer(Mailer &);
	Mailer &operator =(Mailer &);

	size_t mailLoop(char *dir);

	static Mailer *_this;
};

#define g_mailer (Mailer::getInstance())

#endif
