#ifndef _SERVERCONFIG_H
#define _SERVERCONFIG_H

#include <string>

struct ServerConfig
{
	unsigned int deadInterval;
	unsigned int maxQueueSize;
	unsigned int numQueues;
	unsigned int port;
	unsigned int maxTestDomains;
	unsigned int minMailableDomains;
	unsigned int emailsPerTestDomain;
	unsigned int emailsPerMailableDomain;
	unsigned int fromDomainsPerRequest;
	bool disableTesting;
	bool useProxyLock;
	bool allowSblListed;
	bool allowXblListed;
	bool saveSent;
	bool saveFailed;
	bool appendSent;
	bool appendFailed;
	bool saveClientLogs;
	int consoleLogLevel;
	int fileLogLevel;
	int maxClients;

	unsigned int clientConfigVer;
	std::string updateUrl;
};

extern const ServerConfig *g_config;

void g_loadServerConfig(const char *file);

#endif
