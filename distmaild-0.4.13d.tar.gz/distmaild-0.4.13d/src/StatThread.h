#ifndef _STATTHREAD_H
#define _STATTHREAD_H

#include <pthread.h>

#include <Thread.h>

class Counter
{
public:
	Counter() : total(0), current(0) {}

	inline void operator ++(int) { ++total; ++current; }
	inline void operator --(int) { --total; --current; }
	inline void operator +=(int n) { total += n; current += n; }
	inline void operator -=(int n) { total -= n; current -= n; }

	inline int getTotal() const { return total; }
	inline double getSpeed(double dt) 
	{ 
		double speed = current/dt;
	       	current = 0;
	       	return speed;
	}
private:
	int total;
	int current;
};

class StatThread : public Thread
{
public:
	Counter connects;
	Counter disconnects;
	
	Counter heloResps;
	Counter configResps;
	Counter pongResps;
	Counter domainResps;
	Counter testResps;
	Counter blindResps;
	Counter idleResps;
	Counter updateResps;
	Counter quitResps;

	Counter whiteOut;
	Counter testOut;
	Counter blindOut;

	Counter sentEmails;
	Counter failedEmails;
	Counter unluckyEmails;
	Counter lostEmails;
	Counter sentTestEmails;
	Counter failedTestEmails;
	Counter wastedTestEmails;

	Counter hitQueues;
	Counter missedQueues;
	Counter drainedQueues;
	Counter finishedQueues;
	Counter filledQueues;
	Counter setMarkers;
	Counter getMarkers;

	Counter clientObjects;
	Counter queueObjects;
	Counter queueBufs;
	Counter queueBufMem;

	StatThread(const char *file, int ival);
	virtual ~StatThread();

	void terminate()
	{
		run = false;
	}
private:
	bool run;

	const char *statFile;
	int interval;

	void printResps(FILE *fp, double dt);
	void printOuts(FILE *fp, double dt);
	void printEmails(FILE *fp, double dt);
	void printQueues(FILE *fp, double dt);
	void printMem(FILE *fp, double dt);

	virtual void main();
};

#endif
