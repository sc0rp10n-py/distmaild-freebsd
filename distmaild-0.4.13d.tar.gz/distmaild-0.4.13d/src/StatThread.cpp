#include <stdio.h>

#include <StatThread.h>
#include <Mailer.h>
#include <Client.h>
#include <EmailQueue.h>
#include <Logger.h>
#include <util.h>

namespace {
	void formatSize(char *buf, size_t sz, size_t n)
	{
		if(n > 1048576) {
			snprintf(buf, sz, "%.1fMB", n / 1048576.0);
		} else if( n > 1024) {
			snprintf(buf, sz, "%.1fkB", n / 1024.0);
		} else {
			snprintf(buf, sz, "%dB", n);
		}
	}
}

StatThread::StatThread(const char *file, int ival)
: run(true)
, statFile(file)
, interval(ival)
{}

StatThread::~StatThread()
{}

void StatThread::printResps(FILE *fp, double dt)
{
	int helo   = heloResps.getTotal();
	int config = configResps.getTotal();
	int pong   = pongResps.getTotal();
	int domain = domainResps.getTotal();
	int test   = testResps.getTotal();
	int blind  = blindResps.getTotal();
	int idle   = idleResps.getTotal();
	int update = updateResps.getTotal();
	int quit   = quitResps.getTotal();
	int total  = helo + config + pong + domain + test + blind + idle + update + quit;

	double dhelo   = heloResps.getSpeed(dt);
	double dconfig = configResps.getSpeed(dt);
	double dpong   = pongResps.getSpeed(dt);
	double ddomain = domainResps.getSpeed(dt);
	double dtest   = testResps.getSpeed(dt);
	double dblind  = blindResps.getSpeed(dt);
	double didle   = idleResps.getSpeed(dt);
	double dupdate = updateResps.getSpeed(dt);
	double dquit   = quitResps.getSpeed(dt);
	double dtotal  = dhelo + dconfig + dpong + ddomain + dtest + dblind + didle + dupdate + dquit;

	fprintf(fp, "responses:\n");
	fprintf(fp, " tot:%d h:%d (%.1f%%) c:%d (%.1f%%) p:%d (%.1f%%) d:%d (%.1f%%)\n"
		"   t:%d (%.1f%%) b:%d (%.1f%%) i:%d (%.1f%%) u:%d (%.1f%%) q:%d(%.1f%%)\n",
		total,
		helo,   helo   * 100.0 / total,
		config, config * 100.0 / total,
		pong,   pong   * 100.0 / total,
		domain, domain * 100.0 / total,
		test,   test   * 100.0 / total,
		blind,  blind  * 100.0 / total,
		idle,   idle   * 100.0 / total,
		update, update * 100.0 / total,
		quit,   quit   * 100.0 / total);
	fprintf(fp, " tot:%.1f/s h:%.1f/s (%.1f%%) c:%.1f/s (%.1f%%) p:%.1f/s (%.1f%%) d:%.1f/s (%.1f%%)\n"
		"   t:%.1f/s (%.1f%%) b:%.1f/s (%.1f%%) i:%.1f/s (%.1f%%) u:%.1f/s (%.1f%%) q:%.1f/s(%.1f%%)\n",
		dtotal,
		dhelo,   dhelo   * 100.0 / dtotal,
		dconfig, dconfig * 100.0 / dtotal,
		dpong,   dpong   * 100.0 / dtotal,
		ddomain, ddomain * 100.0 / dtotal,
		dtest,   dtest   * 100.0 / dtotal,
		dblind,  dblind  * 100.0 / dtotal,
		didle,   didle   * 100.0 / dtotal,
		dupdate, dupdate * 100.0 / dtotal,
		dquit,   dquit   * 100.0 / dtotal);
}

void StatThread::printOuts(FILE *fp, double dt)
{
	int white = whiteOut.getTotal();
	int test  = testOut.getTotal();
	int blind = blindOut.getTotal();
	int total = white + test + blind;

	double dwhite = whiteOut.getSpeed(dt);
	double dtest  = testOut.getSpeed(dt);
	double dblind = blindOut.getSpeed(dt);
	double dtotal = dwhite + dtest + dblind;

	fprintf(fp,"out:%d w:%d (%.1f%%) t:%d (%.1f%%) b:%d (%.1f%%)\n",
		total,
		white, white * 100.0 / total,
		test,  test  * 100.0 / total,
		blind, blind * 100.0 / total);
	fprintf(fp,"out:%.1f/s w:%.1f/s (%.1f%%) t:%.1f/s (%.1f%%) b:%.1f/s (%.1f%%)\n",
		dtotal,
		dwhite, dwhite * 100.0 / dtotal,
		dtest,  dtest  * 100.0 / dtotal,
		dblind, dblind * 100.0 / dtotal);
}

void StatThread::printEmails(FILE *fp, double dt)
{
	int sent    = sentEmails.getTotal();
	int failed  = failedEmails.getTotal();
	int unlucky = unluckyEmails.getTotal();
	int lost    = lostEmails.getTotal();
	int tsent   = sentTestEmails.getTotal();
	int tfailed = failedTestEmails.getTotal();
	int twasted = wastedTestEmails.getTotal();
	int ttotal  = tsent + tfailed + twasted;
	int total   = sent + failed + unlucky + twasted + lost;

	double dsent    = sentEmails.getSpeed(dt);
	double dfailed  = failedEmails.getSpeed(dt);
	double dunlucky = unluckyEmails.getSpeed(dt);
	double dlost    = lostEmails.getSpeed(dt);
	double dtsent   = sentTestEmails.getSpeed(dt);
	double dtfailed = failedTestEmails.getSpeed(dt);
	double dtwasted = wastedTestEmails.getSpeed(dt);
	double dttotal  = dtsent + dtfailed + dtwasted;
	double dtotal   = dsent + dfailed + dunlucky + dtwasted + dlost;

	fprintf(fp, "mailing:\n");
	fprintf(fp, " tot:%d s:%d (%.1f%%) f:%d (%.1f%%) u:%d (%.1f%%)"
		" w:%d (%.1f%%) l:%d (%.1f%%)\n", 
		total,
		sent,    sent    * 100.0 / total,
		failed,  failed  * 100.0 / total,
		unlucky, unlucky * 100.0 / total,
		twasted, twasted * 100.0 / total,
		lost,    lost    * 100.0 / total);
	fprintf(fp, " tot:%.1f/s s:%.1f/s (%.1f%%) f:%.1f/s (%.1f%%) u:%.1f/s (%.1f%%)"
		" w:%.1f/s (%.1f%%) l:%.1f/s (%.1f%%)\n",
	       	dtotal,
		dsent   , dsent    * 100.0 / dtotal,
		dfailed , dfailed  * 100.0 / dtotal,
		dunlucky, dunlucky * 100.0 / dtotal,
		dtwasted, dtwasted * 100.0 / dtotal,
		dlost   , dlost    * 100.0 / dtotal);
	fprintf(fp, "testing:\n");
	fprintf(fp, " tst:%d (%.1f%%) s:%d (%.1f%%) f:%d (%.1f%%) w:%d (%.1f%%)\n",
		ttotal,  ttotal  * 100.0 / total,
		tsent,   tsent   * 100.0 / ttotal,
		tfailed, tfailed * 100.0 / ttotal,
		twasted, twasted * 100.0 / ttotal);
	fprintf(fp, " tst:%.1f/s (%.1f%%) s:%.1f/s (%.1f%%) f:%.1f/s (%.1f%%) w:%.1f/s (%.1f%%)\n",
		dttotal,  dttotal  * 100.0 / dtotal,
		dtsent,   dtsent   * 100.0 / dttotal,
		dtfailed, dtfailed * 100.0 / dttotal,
		dtwasted, dtwasted * 100.0 / dttotal);
}

void StatThread::printQueues(FILE *fp, double dt)
{
//	int hit      = hitQueues.getTotal();
//	int missed   = missedQueues.getTotal();
//	int drained  = drainedQueues.getTotal();
//	int finished = finishedQueues.getTotal();
//	int filled   = filledQueues.getTotal();
//	int total    = hit + missed + drained + finished + filled;

	double dhit      = hitQueues.getSpeed(dt);
	double dmissed   = missedQueues.getSpeed(dt);
	double ddrained  = drainedQueues.getSpeed(dt);
	double dfinished = finishedQueues.getSpeed(dt);
	double dfilled   = filledQueues.getSpeed(dt);
	double dsets     = setMarkers.getSpeed(dt);
	double dgets     = getMarkers.getSpeed(dt);

	fprintf(fp, "queues:%d hit:%.1f/s miss:%.1f/s drain:%.1f/s fini:%.1f/s fill:%.1f/s s:%.1f/s g:%.1f/s\n",
		g_mailer.getPoolSize(), dhit, dmissed, ddrained, dfinished, dfilled, dsets, dgets);
}

void StatThread::printMem(FILE *fp, double dt)
{
	char cobjmem[16], qobjmem[16], qbufmem[16], totmem[16];

	int cobj = clientObjects.getTotal();
	int qobj = queueObjects.getTotal();
	int qbuf = queueBufs.getTotal();
	int qmem = queueBufMem.getTotal();

	formatSize(cobjmem, sizeof(cobjmem), cobj * sizeof(Client));
	formatSize(qobjmem, sizeof(qobjmem), qobj * sizeof(EmailQueue));
	formatSize(qbufmem, sizeof(qbufmem), qmem);
	formatSize(totmem,  sizeof(totmem),  cobj * sizeof(Client) + qobj * sizeof(EmailQueue) + qmem);

	fprintf(fp, "cobj:%d (%s) qobj:%d (%s) qbuf:%d (%s) total:%s\n",
		cobj, cobjmem, qobj, qobjmem, qbuf, qbufmem, totmem);
}

void StatThread::main()
{
	FILE *fp;
	util::microtime_t t0;
	int npreh, nidle, nwork, nquit;
	double dt;
	char tstr[20];
	time_t t;
	tm lt;

	fp = fopen(statFile, "wt");
	if(fp == NULL) {
		g_log.logf(LOG_FATAL, "Cannot open stats file %s\n", statFile);
		exit(1);
	}

	// XXX
	t0 = util::microtime();
	while(run) {
		int numClients = g_mailer.getTotalClients();
		g_mailer.countClients(npreh, nidle, nwork, nquit);

		dt = (util::microtime() - t0) / 1000000.;
		t0 = util::microtime();

		time(&t);
		localtime_r(&t, &lt);
		strftime(tstr, sizeof(tstr), "%b %d %H:%M:%S", &lt);

		fprintf(fp, "--- %s\n", tstr);
		fprintf(fp, "clients:%d preh:%d idle:%d work:%d quit:%d conn:%.1f/s, disconn:%.1f/s\n",
			numClients, npreh, nidle, nwork, nquit, connects.getSpeed(dt), disconnects.getSpeed(dt));

		printResps(fp, dt);
		printOuts(fp, dt);
		printEmails(fp, dt);
		printQueues(fp, dt);
		printMem(fp, dt);

		fflush(fp);

		sleep(interval);
		
	}

	fclose(fp);
}

