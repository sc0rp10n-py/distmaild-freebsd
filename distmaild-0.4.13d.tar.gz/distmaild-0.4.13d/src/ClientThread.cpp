#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>

#include <Client.h>
#include <ClientThread.h>
#include <Mailer.h>
#include <Logger.h>

ClientThread::ClientThread()
: numClients(0)
{
	pthread_mutex_init(&newClientsMutex, NULL);
	
	poller.init();
}

ClientThread::~ClientThread()
{
	pthread_mutex_destroy(&newClientsMutex);

	// XXX some other cleanup
	poller.shutdown();
}

void ClientThread::addClient(int sock, const sockaddr_in &addr)
{
	pthread_mutex_lock(&newClientsMutex);
	newClients.push_back(std::pair<int, sockaddr_in>(sock, addr));
	pthread_mutex_unlock(&newClientsMutex);

	poller.wakeUp();
}

void ClientThread::countClients(int &npreh, int &nidle, int &nwork, int &nquit)
{
	for(ClientList::iterator it = clientList.begin();
		it != clientList.end();
		++it)
	{
		switch((*it)->getState()) {
		case Client::CLIENT_STATE_PREHELO:  ++npreh;  break;
		case Client::CLIENT_STATE_IDLE:     ++nidle;  break;
		case Client::CLIENT_STATE_WORKING:  ++nwork;  break;
		case Client::CLIENT_STATE_QUITTING: ++nquit;  break;
		}
	}
}

void ClientThread::main()
{
	Poller::PollEvent pe;
	time_t lastCheckDead = 0;
	time_t t;
	int n;

	poller.initWakeUpPipe();

	while(1) {
		t = time(NULL);
		if((t-lastCheckDead) >= 3) {
			for(ClientList::iterator it = clientList.begin(); it != clientList.end(); ++it) {
				(*it)->checkDead(t);
			}
			
			g_log.logf(LOG_INFO, "Done checking for zombies\n");

			lastCheckDead = t;
		}

		n = poller.waitForEvents(1000);
	       	if(n!=0 && n!=EWOULDBLOCK) {
			g_log.logf(LOG_FATAL, "waitForEvents: failed %d\n", n);
			abort();
		}
		
		g_mailer.getBigLock();

		pthread_mutex_lock(&newClientsMutex);

		while(!newClients.empty()) {
			Client *cp = new Client(*this, newClients.back().first, newClients.back().second);

			clientList.push_front(cp);
			cp->setToken(clientList.begin());
			newClients.pop_back();
			++numClients;
		}

		pthread_mutex_unlock(&newClientsMutex);

		t = time(NULL);

		while(poller.getNextEvent(&pe) == 0) {
			Poller::Client *client = pe.client;
			if(client != NULL) {
				client->notifyPollEvent(&pe, t);
			}
		}

		while(!deadClients.empty()) {
			delete *deadClients.back();
			clientList.erase(deadClients.back());
			deadClients.pop_back();
			--numClients;
		}

		g_mailer.releaseBigLock();
	}
}
