#ifndef _LISTSCANNER_H
#define _LISTSCANNER_H

#include <sys/types.h>
#include <sys/stat.h>
#include <fts.h>

class ListScanner
{
public:
	explicit ListScanner(char *path);
	~ListScanner();

	const char *nextQueue();
private:
	FTS *fts;
};

#endif
