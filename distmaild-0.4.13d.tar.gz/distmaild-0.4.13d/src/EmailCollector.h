#ifndef _EMAILCOLLECTOR_H
#define _EMAILCOLLECTOR_H

#include <string>
#include <pthread.h>

#include <Thread.h>

class EmailCollector : public Thread
{
public:
	EmailCollector(const char *file, size_t bufsz, bool a);
	virtual ~EmailCollector();

	bool putEmail(const char *ep, size_t len, const char *dp, size_t dlen);

	void terminate()
	{
		done = true;
		pthread_cond_signal(&flushCond);
	}
private:
	volatile bool done;
	
	char *memBuf;
	char *diskBuf;
	size_t memBufPos;
	size_t diskBufPos;
	size_t bufSize;

	bool append;

	std::string fileName;

	virtual void main();

	pthread_mutex_t mutex;
	pthread_cond_t flushCond;
	pthread_mutex_t flushCondMutex;
};

#endif
