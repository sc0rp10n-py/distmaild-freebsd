#ifndef _LOGGER_H
#define _LOGGER_H

#include <stdio.h>
#include <stdarg.h>
#include <pthread.h>

enum
{
	LOG_NONE,
	LOG_FATAL,
	LOG_ERROR,
	LOG_WARNING,
	LOG_INFO,
	LOG_TRACE
};
	
class Logger
{
public:
	void setConsoleLogLevel(int level) { consLevel = level; }
	void setFileLogLevel(int level) { fileLevel = level; }

	bool setLogFile(const char *file, const char *mode);

	void logf(int level, const char *fmt, ...);

	static Logger &getInstance()
	{
		static Logger me;
		return me;
	}
private:
	FILE *logFile;

	int consLevel;
	int fileLevel;

	pthread_mutex_t mtx;
	
	Logger();
	~Logger();

	/*
	 * These two members are purposedly left unimplemented.
	 */
	Logger(Logger &);
	Logger &operator =(Logger &);
};

#define g_log (Logger::getInstance())

#endif
