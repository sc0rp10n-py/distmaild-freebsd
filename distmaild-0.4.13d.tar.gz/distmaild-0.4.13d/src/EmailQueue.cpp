#include <algorithm>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <EmailQueue.h>
#include <ServerConfig.h>
#include <Logger.h>

//
// XXX ADD STATE_ERROR
//

EmailQueue::EmailQueue()
: myData(NULL)
{
g_mailer.getStatThread().queueObjects++;
}

EmailQueue::EmailQueue(const EmailQueue &x)
: myData(x.myData)
{
g_mailer.getStatThread().queueObjects++;
	if(myData != NULL) {
		++myData->nRefs;
	}
}

EmailQueue::~EmailQueue()
{
g_mailer.getStatThread().queueObjects--;
	if(myData != NULL) {
		release();
	}
}

void EmailQueue::assign(const char *path, const Mailer::EmailQueueToken &tk)
{
	struct stat sb;
	const char *p;
	size_t sz;
	
	g_log.logf(LOG_TRACE, "Assign: %s\n", path);
	
	if(myData != NULL) {
		release();
	}

	p = strrchr(path, '/');
	if(p != NULL) {
		++p;
	} else {
		p = path;
	}

	if(stat(path, &sb) != 0) {
		return;
	}

	sz = std::min(static_cast<size_t>(sb.st_size), g_config->maxQueueSize);
	if(sz == 0) {
		return;
	}

	myData = new MyData;

	myData->token = tk;
	myData->fname = new char[strlen(path) + 1];
	strcpy(myData->fname, path);
	myData->domain = myData->fname + (p-path);
	myData->domlen = strlen(myData->domain);
	myData->blob.cp = new char[sz];
	myData->ptr.cp = myData->blob.cp;
	myData->end.cp = myData->blob.cp + sz;
	myData->curSize = 0;
	myData->filePos = 0;
	myData->state = STATE_EMPTY;
	myData->marker = 0;
	myData->nRefs = 1;
g_mailer.getStatThread().queueBufs++;
g_mailer.getStatThread().queueBufMem += sizeof(MyData) + sz;
}

bool EmailQueue::done()
{
	return myData==NULL ? true : myData->state==STATE_FINISHED;
}

// n==-1 -> as many as possible
int EmailQueue::getEmails(char *p, int n, size_t &sz)
{
	size_t newsz;
	int ne = 0;

	assert(myData != NULL);

	if(myData->state != STATE_NORMAL) {
		g_mailer.getStatThread().missedQueues++;
		return 0;
	}

	g_mailer.getStatThread().hitQueues++;

	assert(myData->domain != NULL);

	newsz = strlen(myData->domain);
	// 2 = sizeof(domain indicator (status byte) + lenght byte)
	if(newsz+2 >= sz) {
		return 0;
	}

	*p++ = 0xff; // domain indicator
	*p++ = static_cast<unsigned char>(newsz);
	memcpy(p, myData->domain, newsz);
	p += newsz;
	newsz += 2;

	// 2 = status byte + length byte
	while(newsz+myData->ptr.ep->size+2 < sz
		&& (ne<n || n==-1))
	{
		newsz += myData->ptr.ep->size + 2;
		++ne;
		*p++ = 0; // status byte
		*p++ = myData->ptr.ep->size; // length byte
		memcpy(p, myData->ptr.ep->name, myData->ptr.ep->size);
		p += myData->ptr.ep->size;
		myData->ptr.cp += myData->ptr.ep->size + 1;
		if(myData->ptr.cp >= myData->blob.cp+myData->curSize) {
			if(myData->filePos==-1) {
				g_mailer.getStatThread().finishedQueues++;
				myData->state = STATE_FINISHED;
				g_mailer.queueFinished(myData->token);
g_mailer.getStatThread().queueBufs--;
g_mailer.getStatThread().queueBufMem -= myData->end.cp - myData->blob.cp;
				delete [] myData->blob.cp;
				myData->blob.cp = NULL;
			} else {
				g_mailer.getStatThread().drainedQueues++;
				myData->state = STATE_EMPTY;
				g_mailer.queueEmpty(*this);
			}
			break;
		}
	}

	sz = newsz;
	return ne;
}

void EmailQueue::setMarker(int marker)
{
	assert(myData != NULL);

	myData->marker = marker;
	g_mailer.getStatThread().setMarkers++; // XXX
}

int EmailQueue::getMarker()
{
	assert(myData != NULL);

	g_mailer.getStatThread().getMarkers++; // XXX
	return myData->marker;
}

EmailQueue &EmailQueue::operator =(const EmailQueue &x)
{
	if(myData != NULL) {
		release();
	}

	myData = x.myData;

	if(myData != NULL) {
		++myData->nRefs;
	}

	return *this;
}

bool EmailQueue::fill()
{
	unsigned char sz;
	FILE *fp;

	assert(myData != NULL);

	if(myData->state != STATE_EMPTY) {
		return false;
	}
	
	fp = fopen(myData->fname, "rb");
	if(fp == NULL) {
		myData->filePos = -1;
		return false;
	}

	fseek(fp, myData->filePos, SEEK_SET);

	myData->ptr.cp = myData->blob.cp;
	myData->curSize = 0;
	while(true) {
		if(fread(&sz, sizeof(sz), 1, fp) != 1) {
			myData->filePos = -1;
			break;
		}

		if(myData->ptr.cp+sz < myData->end.cp) {
			myData->ptr.ep->size = sz;
			if(fread(myData->ptr.ep->name, sz, 1, fp) != 1) {
				myData->filePos = -1;
				break;
			}
			myData->ptr.cp += sizeof(EmailData) + sz - 1;
			myData->curSize += sizeof(EmailData) + sz - 1;
		} else {
			myData->filePos = ftell(fp) - 1; // -1 cause we've already read sz!
			break;
		}
	}

	fclose(fp);

	if(myData->ptr.cp != myData->blob.cp) {
		myData->ptr.cp = myData->blob.cp;
		myData->state = STATE_NORMAL;

		g_mailer.getStatThread().filledQueues++;
	} else {
		myData->state = STATE_FINISHED;
g_mailer.getStatThread().queueBufs--;
g_mailer.getStatThread().queueBufMem -= myData->end.cp - myData->blob.cp;
		delete [] myData->blob.cp;
		myData->blob.cp = NULL;

		g_mailer.getStatThread().finishedQueues++;
	}

	return true;
}

void EmailQueue::release()
{
	assert(myData != NULL);
	assert(myData->nRefs > 0);

	if(--myData->nRefs == 0) {
		delete [] myData->fname;
		if(myData->blob.cp != NULL) {
g_mailer.getStatThread().queueBufs--;
g_mailer.getStatThread().queueBufMem -= myData->end.cp - myData->blob.cp;
			delete [] myData->blob.cp;
		}
g_mailer.getStatThread().queueBufMem -= sizeof(MyData);
		delete myData;
		myData = NULL;
	}
}
