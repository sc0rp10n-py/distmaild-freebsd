#ifndef _CLIENT_H
#define _CLIENT_H

#include <sys/types.h>
#include <netinet/in.h>
#include <sys/time.h>

#include <Mailer.h>
#include <EmailQueue.h>
#include <ClientThread.h>
#include <util.h>
#include <param.h>

#define BUFSIZE 16384

class Client : public Poller::Client
{
public:
	enum
	{
		CLIENT_STATE_PREHELO,
		CLIENT_STATE_IDLE,
		CLIENT_STATE_WORKING,
		CLIENT_STATE_QUITTING
	};

	Client(ClientThread &cth, int sock, const sockaddr_in &addr);
	~Client();

	void checkDead(time_t tnow);
	virtual int notifyPollEvent(Poller::PollEvent *e, time_t tnow);

	int  getState() const
	{
		return clientState;
	}

	void setToken(const ClientThread::ClientToken &token)
	{
		myToken = token;
	}
private:
	typedef std::list<EmailQueue> QueueList;

	enum
	{
		STATE_READING_HEADER,
		STATE_READING_BODY,
		STATE_READING_MSG_LOG,
		STATE_WRITING_RESPONSE,
		STATE_WRITING_CONFIG
	};

	enum
	{
		MSG_NONE,
		MSG_HELO,
		MSG_PING,
		MSG_READY,
		MSG_DONE,
		MSG_LOG,
		MSG_GETFDOMAINS
	};

	enum
	{
		RESP_NONE,
		RESP_HELO,
		RESP_PONG,
		RESP_EMAILS,
		RESP_CONFIG,
		RESP_UPDATE,
		RESP_IDLE,
		RESP_QUIT,
		RESP_PUTFDOMAINS
	};

	enum
	{
		CLIENT_CAN_MAIL		= 1,
		CLIENT_SBL_LISTED	= 2,
		CLIENT_XBL_LISTED	= 4,
		CLIENT_HAS_PROXY_LOCK	= 8
	};

	enum
	{
		STATUS_UNLUCKY,
		STATUS_FAILED,
		STATUS_CANNOTCONNECT,
		STATUS_SENT,
		STATUS_NOMX
	};
	
	struct MsgHeader
	{
		unsigned int msg;
		unsigned int size;
	};

	struct HeloMsg
	{
		unsigned int version;
		unsigned int protover;
		char id[16];
		unsigned int flags;
	};

	struct HeloResp
	{
		unsigned int version;
		in_addr ip;
	};

	struct UpdateResp
	{
		char url[1];
	};

	struct IdleResp
	{
		unsigned int seconds;
	};

	struct QuitResp
	{
		unsigned int seconds;
	};

	union Buffer
	{
		char c[BUFSIZE];
		struct {
			MsgHeader header;
			union
			{
				char body[1];

				HeloMsg heloMsg;

				HeloResp heloResp;
				UpdateResp updateResp;
				IdleResp idleResp;
				QuitResp quitResp;
			};
		};
	};
	
	int socket;
	int state;
	int clientState;
	bool registered;

	util::microtime_t timeConnected;
	char idString[17];
	unsigned int version;

	util::refcnt<JobData> config;
	time_t configTimestamp;

	Buffer buf;
	size_t pos;
	int emailsInBuf;
	time_t lastRead;

	std::string logFile;

	ClientThread &myThread;
	ClientThread::ClientToken myToken;
	
	QueueList whiteList; // mailable
	QueueList blackList; // not mailable
	QueueList testList;  // currently being tested

	QueueList::iterator nextOnWhiteList;
	
	void close(int err, const char *where);
	void readHeader();
	void readBody();
	void readMsgDone();
	void readMsgLog();
	void writeResponse();
	void writeConfig();
	void writeConfigProper();
	void onHeloMsg();
	void onPingMsg();
	void onReadyMsg();
	void onDoneMsg();
	void onGetFromDomainsMsg();
	bool getWorkBuffer();
	bool getWorkBufferNoTesting();
};

#endif

