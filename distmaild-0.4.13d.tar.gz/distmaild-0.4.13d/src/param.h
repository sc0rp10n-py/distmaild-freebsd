#ifndef _PARAM_H
#define _PARAM_H

#define PARAM_LOG_DIR		"log"
#define PARAM_PROTOCOL_VER	0x204

#endif
