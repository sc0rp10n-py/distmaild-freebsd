#ifndef _THREAD_H
#define _THREAD_H

#include <pthread.h>

class Thread
{
public:
	virtual ~Thread() {}

	bool start()
	{
		return pthread_create(&myThreadId, NULL, &Thread::_main, this) == 0;
	}
	
	bool join()
	{
		return pthread_join(myThreadId, NULL) == 0;
	}
	
	bool detach()
	{
		return pthread_detach(myThreadId) == 0;
	}
protected:
	virtual void main() = 0;
private:
	pthread_t myThreadId;

	static void *_main(void *arg);
};

#endif
