#include <signal.h>
#include <stdio.h>
#include <stdlib.h>

#include <Mailer.h>
#include <ServerConfig.h>
#include <Logger.h>

int g_verMajor = 0;
int g_verMinor = 0;
int g_verRelease = 0;

namespace {
	void reloadConfig(int)
	{
		g_mailer.reloadConfig();
	}

	void die(int)
	{
		fprintf(stderr, "dying\n");
		exit(0);
	}
}

int main()
{
	FILE *fp;

	sscanf(VERSION, "%d.%d.%d", &g_verMajor, &g_verMinor, &g_verRelease);

	srand(time(NULL));

#ifdef xDEBUG
	g_log.setConsoleLogLevel(LOG_TRACE);
	g_log.setFileLogLevel(LOG_TRACE);
#else
	g_log.setConsoleLogLevel(LOG_INFO);
	g_log.setFileLogLevel(LOG_INFO);
#endif

	if(!g_log.setLogFile("distmaild.log", "wt")) {
		g_log.logf(LOG_ERROR, "Cannot open log file\n");
	}

	g_log.logf(LOG_INFO, "This is distmaild " VERSION ", %s build\n",
		g_verMajor, g_verMinor, g_verRelease,
#ifdef DEBUG
		"DEBUG"
#else
		"release"
#endif
		);

	fp = fopen("pid", "w");
	fprintf(fp, "%d", getpid());
	fclose(fp);
	
	g_loadServerConfig("serverconfig");
	g_log.setConsoleLogLevel(g_config->consoleLogLevel);
	g_log.setFileLogLevel(g_config->fileLogLevel);

	signal(SIGPIPE, SIG_IGN);
	signal(SIGTERM, die);
	signal(SIGHUP, reloadConfig);

	Mailer::create();
	g_mailer.start();

	return 0;
}
