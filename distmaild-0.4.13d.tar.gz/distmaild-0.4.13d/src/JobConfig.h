#ifndef _JOBCONFIG_H
#define _JOBCONFIG_H

#include <vector>
#include <assert.h>
#include <string.h>

#include <util.h>

struct JobData
{
	~JobData() { delete [] ptr; }

	char *ptr;
	size_t size;
};

class JobConfig
{
public:
	JobConfig::JobConfig() : timestamp(0) {}

	void read();
	bool getData(util::refcnt<JobData> &cfg, time_t &ts);
private:
	enum
	{
		CONFIG_IGNORE_CLIENT_HOSTNAME = 1
	};

	struct Config
	{
		unsigned int minRecipients;
		unsigned int maxRecipients;
		unsigned int numThreads;
		unsigned int delay;
		unsigned int maxMxs;
		unsigned int logLevel;
		unsigned int flags;
		unsigned int failedStrsSize;
		unsigned int templatesSize;
	};

	time_t timestamp;
	std::vector<util::refcnt<JobData> > configs;

	bool         readBool(const char *file);
	unsigned int readUInt(const char *file);
	unsigned int readStr(const char *file, std::string &s);
	unsigned int readStrArr(const char *file, std::string &s);
	//unsigned int readTemplates(const char *file, std::string &s);
};

#endif
