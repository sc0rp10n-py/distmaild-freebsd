#include <stdlib.h>

#include <ServerConfig.h>
#include <ConfigFile.h>
#include <Logger.h>

const ServerConfig *g_config;

namespace {
	const char *bool2str(bool b)
	{
		return b ? "true" : "false";
	}
}

void g_loadServerConfig(const char *file)
{
	ServerConfig *cfg = new ServerConfig;

	try {
		ConfigFile cfgFile(file);

		cfg->deadInterval            = cfgFile.read("dead_interval"             , 240);
		cfg->maxQueueSize            = cfgFile.read("max_queue_size"            , 8192);
		cfg->numQueues               = cfgFile.read("num_queues"                , 262144);
		cfg->port                    = cfgFile.read("port"                      , 25003);
		cfg->maxTestDomains          = cfgFile.read("max_test_domains"          , 20);
		cfg->minMailableDomains      = cfgFile.read("min_mailable_domains"      , 30);
		cfg->emailsPerTestDomain     = cfgFile.read("emails_per_test_domain"    , 1);
		cfg->emailsPerMailableDomain = cfgFile.read("emails_per_mailable_domain", 10);
		cfg->fromDomainsPerRequest   = cfgFile.read("from_domains_per_request"  , 10);
		cfg->disableTesting          = cfgFile.read("disable_testing"           , false);
		cfg->useProxyLock            = cfgFile.read("use_proxy_lock"            , false);
		cfg->allowSblListed          = cfgFile.read("allow_sbl_listed"          , false);
		cfg->allowXblListed          = cfgFile.read("allow_xbl_listed"          , false);
		cfg->saveSent                = cfgFile.read("save_sent"                 , false);
		cfg->saveFailed              = cfgFile.read("save_failed"               , false);
		cfg->appendSent              = cfgFile.read("append_sent"               , true);
		cfg->appendFailed            = cfgFile.read("append_failed"             , true);
		cfg->saveClientLogs          = cfgFile.read("save_client_logs"          , false);
		cfg->consoleLogLevel         = cfgFile.read("console_log_level"         , 3);
		cfg->fileLogLevel            = cfgFile.read("file_log_level"            , 3);
		cfg->maxClients              = cfgFile.read("max_clients"               , 1024);

		cfg->clientConfigVer         = cfgFile.read<unsigned int>("client_config_version");
		cfg->updateUrl               = cfgFile.read<std::string> ("update_url");
	} catch(ConfigFile::file_not_found &e) {
		g_log.logf(LOG_FATAL, "Cannot open config file %s\n", e.filename.c_str());
		exit(1);
	} catch(ConfigFile::key_not_found &e) {
		g_log.logf(LOG_FATAL, "Mandatory config parameter %s not found\n", e.key.c_str());
		exit(1);
	}

	if(cfg->useProxyLock) {
		cfg->disableTesting = true;
	}

	g_config = cfg;

	g_log.logf(LOG_INFO, "Configuration:\n");
	g_log.logf(LOG_INFO, " dead_interval              = %u\n", cfg->deadInterval);
	g_log.logf(LOG_INFO, " max_queue_size             = %u\n", cfg->maxQueueSize);
	g_log.logf(LOG_INFO, " num_queues                 = %u\n", cfg->numQueues);
	g_log.logf(LOG_INFO, " port                       = %u\n", cfg->port);
	g_log.logf(LOG_INFO, " max_test_domains           = %u\n", cfg->maxTestDomains);
	g_log.logf(LOG_INFO, " min_mailable_domains       = %u\n", cfg->minMailableDomains);
	g_log.logf(LOG_INFO, " emails_per_test_domain     = %u\n", cfg->emailsPerTestDomain);
	g_log.logf(LOG_INFO, " emails_per_mailable_domain = %u\n", cfg->emailsPerMailableDomain);
	g_log.logf(LOG_INFO, " from_domains_per_request   = %u\n", cfg->fromDomainsPerRequest);
	g_log.logf(LOG_INFO, " disable_testing            = %s\n", bool2str(cfg->disableTesting));
	g_log.logf(LOG_INFO, " use_proxy_lock             = %s\n", bool2str(cfg->useProxyLock));
	g_log.logf(LOG_INFO, " allow_sbl_listed           = %s\n", bool2str(cfg->allowSblListed));
	g_log.logf(LOG_INFO, " allow_xbl_listed           = %s\n", bool2str(cfg->allowXblListed));
	g_log.logf(LOG_INFO, " save_sent                  = %s\n", bool2str(cfg->saveSent));
	g_log.logf(LOG_INFO, " save_failed                = %s\n", bool2str(cfg->saveFailed));
	g_log.logf(LOG_INFO, " append_sent                = %s\n", bool2str(cfg->appendSent));
	g_log.logf(LOG_INFO, " append_failed              = %s\n", bool2str(cfg->appendFailed));
	g_log.logf(LOG_INFO, " save_client_logs           = %s\n", bool2str(cfg->saveClientLogs));
	g_log.logf(LOG_INFO, " console_log_level          = %d\n", cfg->consoleLogLevel);
	g_log.logf(LOG_INFO, " file_log_level             = %d\n", cfg->fileLogLevel);
	g_log.logf(LOG_INFO, " max_clients                = %d\n", cfg->maxClients);
	g_log.logf(LOG_INFO, " client_config_version      = %d\n", cfg->clientConfigVer);
	g_log.logf(LOG_INFO, " update_url                 = %s\n", cfg->updateUrl.c_str());
}
