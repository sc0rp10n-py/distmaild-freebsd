#ifndef _UTIL_H
#define _UTIL_H

#include <ext/hash_set>
#include <sys/time.h>

namespace util
{
	/*
	 * WTF those two structs are not in std:: or ext::?!
	 */
	struct cstr_eq
	{
		bool operator ()(const char *s1, const char *s2) const
		{
			return strcmp(s1, s2) == 0;
		}
	};

	struct stlstr_hash
	{
		size_t operator()(const std::string &s) const
		{
			return hasher(s.c_str());
		}

		__gnu_cxx::hash<const char *> hasher;
	};

	/*
	 * Same as time_t and time() but in microseconds.
	 */
	typedef unsigned long long microtime_t;

	inline microtime_t microtime()
	{
		timeval tv;

		gettimeofday(&tv, NULL);
		return (microtime_t)tv.tv_sec*1000000 + tv.tv_usec;
	}

	template<class T>
	class refcnt
	{
	public:
		refcnt() : data(NULL) {}

		refcnt(const T &x) : data(new Data(x)) {}
		
		refcnt(const refcnt<T> &x) : data(x.data)
		{
			if(data != NULL) {
				++data->refs;
			}
		}
		
		~refcnt() { dealloc(); }
		
		void alloc()
		{
			dealloc();
			data = new Data;
		}
		
		void dealloc()
		{
			if(data!=NULL && --data==0) {
				delete data;
			}

			data = NULL;
		}
		
		refcnt<T> &operator =(const T &x)
		{
			dealloc();
			data = new Data(x);

			return *this;
		}
		
		refcnt<T> &operator =(const refcnt<T> &x)
		{
			dealloc();

			data = x.data;
			if(data != NULL) {
				++data->refs;
			}

			return *this;
		}

		T &operator *() { return data->t; }

		const T&operator *() const { return data->t; }
		
		T *operator ->() { return &data->t; }
		
		const T*operator ->() const { return &data->t; }
	private:
		struct Data
		{
			Data() : refs(1) {}
			explicit Data(const T &x) : t(x), refs(1) {}

			T t;
			unsigned int refs;
		} *data;
	};
}

#endif
